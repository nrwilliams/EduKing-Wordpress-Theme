<?php
/**
 * This file has all the main shortcode functions
 * @package Symple Shortcodes Plugin
 * @since 1.0
 * @author AJ Clarke : http://sympleplorer.com
 * @copyright Copyright (c) 2012, AJ Clarke
 * @link http://sympleplorer.com
 * @License: GNU General Public License version 2.0
 * @License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */


/*
 * Allow shortcodes in widgets
 * @since v1.0
 */
add_filter('widget_text', 'do_shortcode');



/*
 * Fix Shortcodes
 * @since v1.0
 */
if( !function_exists('tgreen_fix_shortcodes') ) {
	function tgreen_fix_shortcodes($content){   
		$array = array (
			'<p>['		=> '[', 
			']</p>'		=> ']', 
			']<br />'	=> ']'
		);
		$content = strtr($content, $array);
		return $content;
	}
	add_filter('the_content', 'tgreen_fix_shortcodes');
}


/*
 * Clear Floats
 * @since v1.0
 */
if( !function_exists('tgreen_clear_floats_shortcode') ) {
	function tgreen_clear_floats_shortcode() {
	   return '<div class="tgreen-clear-floats"></div>';
	}
	add_shortcode( 'tgreen_clear_floats', 'tgreen_clear_floats_shortcode' );
}


/*
 * Callout
 * @since v1.4
 */
if( !function_exists('tgreen_callout_shortcode') ) {
	function tgreen_callout_shortcode( $atts, $content = NULL  ) {		
		extract( shortcode_atts( array(
			'caption'				=> '',
			'button_text'			=> '',
			'button_color'			=> 'blue',
			'button_url'			=> 'http://www.wpexplorer.com',
			'button_rel'			=> 'nofollow',
			'button_target'		=> 'blank',
			'button_border_radius'=> '',
			'class'					=> '',
			'icon_left'			=> '',
			'icon_right'			=> '',
			'visibility'			=> 'all',
		), $atts ) );
		
		$border_radius_style = ( $button_border_radius ) ? 'style="border-radius:'. $button_border_radius .'"' : NULL;
		$output = '<div class="symple-callout symple-clearfix '. $class .' symple-'. $visibility .'">';
		$output .= '<div class="symple-callout-caption">';
			if ( $icon_left ) $output .= '<span class="symple-callout-icon-left icon-'. $icon_left .'"></span>';
			$output .= do_shortcode ( $content );
			if ( $icon_right ) $output .= '<span class="symple-callout-icon-right icon-'. $icon_right .'"></span>';
		$output .= '</div>';	
		if ( $button_text !== '' ) {
			$output .= '<div class="symple-callout-button">';
				$output .='<a href="'. $button_url .'" title="'. $button_text .'" target="_'. $button_target .'" class="symple-button '.$button_color .'" '. $border_radius_style .'><span class="symple-button-inner">'. $button_text .'</span></a>';
			$output .='</div>';
		}
		$output .= '</div>';
		
		return $output;
	}
	add_shortcode( 'tgreen_callout', 'tgreen_callout_shortcode' );
}


/*
 * Skillbars
 * @since v1.3
 */
if( !function_exists('tgreen_skillbar_shortcode') ) {
	function tgreen_skillbar_shortcode( $atts  ) {		
		extract( shortcode_atts( array(
			'title'			=> '',
			'percentage'	=> '100',
			'color'			=> '#6adcfa',
			'class'			=> '',
			'show_percent'	=> 'true',
			'visibility'	=> 'all',
		), $atts ) );
		
		// Enque scripts
		wp_enqueue_script('symple_skillbar');
		
		// Display the accordion	';
		$output = '<div class="symple-skillbar symple-clearfix '. $class .' symple-'. $visibility .'" data-percent="'. $percentage .'%">';
			if ( $title !== '' ) $output .= '<div class="symple-skillbar-title"><span>'. $title .'</span></div>';
			$output .= '<div class="symple-skillbar-bar" style="background: '. $color .';"></div>';
			if ( $show_percent == 'true' ) {
				$output .= '<div class="symple-skill-bar-percent">'.$percentage.'%</div>';
			}
		$output .= '</div>';
		
		return $output;
	}
	add_shortcode( 'tgreen_skillbar', 'tgreen_skillbar_shortcode' );
}


/*
 * Spacing
 * @since v1.0
 */
if( !function_exists('tgreen_spacing_shortcode') ) {
	function tgreen_spacing_shortcode( $atts ) {
		extract( shortcode_atts( array(
			'size'	=> '20px',
			'class'	=> '',
		  ),
		  $atts ) );
	 return '<hr class="symple-spacing '. $class .'" style="height: '. $size .'" />';
	}
	add_shortcode( 'tgreen_spacing', 'tgreen_spacing_shortcode' );
}


/**
* Social Icons
* @since 1.0
*/
if( !function_exists('tgreen_social_shortcode') ) {
	function tgreen_social_shortcode( $atts ){   
		extract( shortcode_atts( array(
			'icon'				=> 'twitter',
			'url'				=> 'http://www.twitter.com/sympleplorer',
			'title'				=> 'Follow Us',
			'target'			=> 'self',
			'rel'				=> '',
			'border_radius'	=> '',
			'class'				=> '',
		), $atts ) );
		$icons_url = plugin_dir_url( __FILE__ ) .'images/social/';
		$icons_url = apply_filters( 'symple_social_icon_url', $icons_url );
		return '<a href="' . $url . '" class="symple-social-icon '. $class .'" target="_'.$target.'" title="'. $title .'" rel="'. $rel .'"
><img src="'. $icons_url . $icon .'.png" alt="'. $icon .'" /></a>';
	}
	add_shortcode('tgreen_social', 'tgreen_social_shortcode');
}

/**
* Highlights
* @since 1.0
*/
if ( !function_exists( 'tgreen_highlight_shortcode' ) ) {
	function tgreen_highlight_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'color'			=> 'yellow',
			'class'			=> '',
			'visibility'	=> 'all',
		  ),
		  $atts ) );
		  return '<span class="symple-highlight symple-highlight-'. $color .' '. $class .' symple-'. $visibility .'">' . do_shortcode( $content ) . '</span>';
	
	}
	add_shortcode('tgreen_highlight', 'tgreen_highlight_shortcode');
}


/*
 * Buttons
 * @since v1.0
 */
if( !function_exists('tgreen_button_shortcode') ) {
	function tgreen_button_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'color'				=> 'blue',
			'url'				=> 'http://www.sympleplorer.com',
			'title'				=> 'Visit Site',
			'target'			=> 'self',
			'rel'				=> '',
			'border_radius'	=> '',
			'class'				=> '',
			'icon_left'		=> '',
			'icon_right'		=> '',
			'visibility'		=> 'all',
		), $atts ) );
		
		
		$border_radius_style = ( $border_radius ) ? 'style="border-radius:'. $border_radius .'"' : NULL;		
		$rel = ( $rel ) ? 'rel="'.$rel.'"' : NULL;
		
		$button = NULL;
		$button .= '<a href="' . $url . '" class="symple-button ' . $color . ' '. $class .' symple-'. $visibility .'" target="_'.$target.'" title="'. $title .'" '. $border_radius_style .' '. $rel .'>';
			$button .= '<span class="symple-button-inner" '.$border_radius_style.'>';
				if ( $icon_left ) $button .= '<span class="symple-button-icon-left icon-'. $icon_left .'"></span>';
				$button .= $content;
				if ( $icon_right ) $button .= '<span class="symple-button-icon-right icon-'. $icon_right .'"></span>';
			$button .= '</span>';			
		$button .= '</a>';
		return $button;
	}
	add_shortcode('tgreen_button', 'tgreen_button_shortcode');
}



/*
 * Boxes
 * @since v1.0
 *
 */
if( !function_exists('tgreen_box_shortcode') ) { 
	function tgreen_box_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'color'				=> 'gray',
			'float'				=> 'center',
			'text_align'		=> 'left',
			'width'				=> '100%',
			'margin_top'		=> '',
			'margin_bottom'	=> '',
			'class'				=> '',
			'visibility'		=> 'all',
		  ), $atts ) );
		  
			$style_attr = '';
			if( $margin_bottom ) {
				$style_attr .= 'margin-bottom: '. $margin_bottom .';';
			}
			if ( $margin_top ) {
				$style_attr .= 'margin-top: '. $margin_top .';';
			}
		  
		  $alert_content = '';
		  $alert_content .= '<div class="symple-box ' . $color . ' '.$float.' '. $class .' symple-'. $visibility .'" style="text-align:'. $text_align .'; width:'. $width .';'. $style_attr .'">';
		  $alert_content .= ' '. do_shortcode($content) .'</div>';
		  return $alert_content;
	}
	add_shortcode('tgreen_box', 'tgreen_box_shortcode');
}



/**
* Service Box
* @since 1.0
*/
if ( !function_exists( 'tgreen_service' ) ) {
	function tgreen_service_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'icon'			=> 'camera-retro',
			'title'			=> '',
			'size'			=> 'one-third',
			'position'		=>'first',
			'button_color'	=> '',
			'url'				=> '',
			'button_title'		=> '',
			'target'			=> 'self',
			'button'			=> '',
		  ),
		  $atts ) );

     $output .= '<div class="symple-column symple-' . $size . ' symple-column-'.$position.'"><div class="service-box"><div class="service-icon"><i class="fa fa-'.$icon.' fa-2x"></i></div><div class="service-info"><h5 style="text-transform: uppercase; font-weight: 900;">'.$title.'</h5><p>' . do_shortcode( $content ) . '</p></div>';		

if ( $button !== 'yes' )  $output .='';

if ( $button !== '' )  $output .='<div style="text-align: center;"><a href="' . $url . '" class="symple-button '. $button_color .'" target="_'.$target.'" ><span class="symple-button-inner-service">'.$button_title.'</span></a></div>';

$output .=' </div></div>'; 

     return $output;

	}
	add_shortcode('tgreen_service', 'tgreen_service_shortcode');
}


/**
* Team Member
* @since 1.0
*/
if ( !function_exists( 'tgreen_team_member' ) ) {
	function tgreen_team_member_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'image'			=> '',
			'name'			=> '',
			'team_title'		=> '',
			'size'			=> 'one-third',
			'position'		=>'first',
		  ),
		  $atts ) );
		  return '<div class="symple-column symple-' . $size . ' symple-column-'.$position.'"><div class="team"><div class="team-img"><img src="'.$image.'"></div><div class="team-name">
<h5>'.$name.'  <br><span style="text-align: center; font-size: smaller; font-weight: 300; color: #616161; text-transform: lowercase;">'.$team_title.'</span></h5></div>
<div class="team-content" style=" text-align: center;margin: 13px 0;">' . do_shortcode( $content ) . '</div></div></div>';

	}
	add_shortcode('tgreen_team_member', 'tgreen_team_member_shortcode');
}


/**
* Icon
* @since 1.0
*/
if ( !function_exists( 'tgreen_icon' ) ) {
	function tgreen_icon_shortcode($atts) {
		extract( shortcode_atts( array(
			'icon'			=> 'camera-retro',
			'size'			=> '',
		  ),
		  $atts ) );
		  return '<i class="fa fa-'.$icon.' fa-'.$size.'"></i>';

	}
	add_shortcode('tgreen_icon', 'tgreen_icon_shortcode');
}



/**
* Lists
* @since 1.0
*/
if ( !function_exists( 'tgreen_list_group' ) ) {
	function tgreen_list_group_shortcode($atts, $content = null) {
		extract( shortcode_atts( array(
			'icon'			=> 'camera-retro',
			'size'			=> '',
		  ),
		  $atts ) );
		  return '<ul class="fa-ul">' . do_shortcode($content) . '</ul>';

	}
	add_shortcode('tgreen_list_group', 'tgreen_list_group_shortcode');
}


if ( !function_exists( 'tgreen_li' ) ) {
	function tgreen_list_item_shortcode($atts, $content = null) {
		extract( shortcode_atts( array(
			'icon'			=> 'check-square',
		  ),
		  $atts ) );
		  return '<li><i class="fa-li fa fa-'.$icon.'"></i>' . do_shortcode($content) . '</li>';

	}
	add_shortcode('tgreen_li', 'tgreen_list_item_shortcode');
}



/*
 * Testimonial
 * @since v1.0
 *
 */
if( !function_exists('tgreen_testimonial_shortcode') ) { 
	function tgreen_testimonial_shortcode( $atts, $content = null  ) {
		extract( shortcode_atts( array(
			'by'			=> '',
			'class'			=> '',
			'visibility'	=> 'all',
		  ), $atts ) );
		$testimonial_content = '';
		$testimonial_content .= '<div class="symple-testimonial '. $class .' symple-'. $visibility .'"><div class="symple-testimonial-content">';
		$testimonial_content .= $content;
		$testimonial_content .= '</div><div class="symple-testimonial-author">';
		$testimonial_content .= $by .'</div></div>';	
		return $testimonial_content;
	}
	add_shortcode( 'tgreen_testimonial', 'tgreen_testimonial_shortcode' );
}



/*
 * Columns
 * @since v1.0
 *
 */
if( !function_exists('tgreen_column_shortcode') ) {
	function tgreen_column_shortcode( $atts, $content = null ){
		extract( shortcode_atts( array(
			'size'			=> 'one-third',
			'position'		=>'first',
			'class'			=> '',
			'visibility'	=> 'all',
		  ), $atts ) );
		  return '<div class="symple-column symple-' . $size . ' symple-column-'.$position.' '. $class .' symple-'. $visibility .'">' . do_shortcode($content) . '</div>';
	}
	add_shortcode('tgreen_column', 'tgreen_column_shortcode');
}



/*
 * Toggle
 * @since v1.0
 */
if( !function_exists('tgreen_toggle_shortcode') ) {
	function tgreen_toggle_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title'			=> 'Toggle Title',
			'class'			=> '',
			'visibility'	=> 'all',
		), $atts ) );
		 
		// Enque scripts
		wp_enqueue_script('symple_toggle');
		
		// Display the Toggle
		return '<div class="symple-toggle '. $class .' symple-'. $visibility .'"><h3 class="symple-toggle-trigger">'. $title .'</h3><div class="symple-toggle-container">' . do_shortcode($content) . '</div></div>';
	}
	add_shortcode('tgreen_toggle', 'tgreen_toggle_shortcode');
}


/*
 * Accordion
 * @since v1.0
 *
 */

// Main
if( !function_exists('tgreen_accordion_main_shortcode') ) {
	function tgreen_accordion_main_shortcode( $atts, $content = null  ) {
		
		extract( shortcode_atts( array(
			'class'			=> '',
			'visibility'	=> 'all',
		), $atts ) );
		
		// Enque scripts
		wp_enqueue_script('jquery-ui-accordion');
		wp_enqueue_script('symple_accordion');
		
		// Display the accordion	
		return '<div class="symple-accordion '. $class .' symple-'. $visibility .'">' . do_shortcode($content) . '</div>';
	}
	add_shortcode( 'tgreen_accordion', 'tgreen_accordion_main_shortcode' );
}


// Section
if( !function_exists('tgreen_accordion_section_shortcode') ) {
	function tgreen_accordion_section_shortcode( $atts, $content = null  ) {
		extract( shortcode_atts( array(
			'title'	=> 'Title',
			'class'	=> '',
		), $atts ) );
		  
	   return '<h3 class="symple-accordion-trigger '. $class .'"><a href="#">'. $title .'</a></h3><div>' . do_shortcode($content) . '</div>';
	}
	
	add_shortcode( 'tgreen_accordion_section', 'tgreen_accordion_section_shortcode' );
}


/*
 * Tabs
 * @since v1.0
 *
 */
if (!function_exists('tgreen_tabgroup_shortcode')) {
	function tgreen_tabgroup_shortcode( $atts, $content = null ) {
		
		//Enque scripts
		wp_enqueue_script('jquery-ui-tabs');
		wp_enqueue_script('symple_tabs');
		
		// Display Tabs
		$defaults = array();
		extract( shortcode_atts( $defaults, $atts ) );
		preg_match_all( '/tab title="([^\"]+)"/i', $content, $matches, PREG_OFFSET_CAPTURE );
		$tab_titles = array();
		if( isset($matches[1]) ){ $tab_titles = $matches[1]; }
		$output = '';
		if( count($tab_titles) ){
		    $output .= '<div id="symple-tab-'. rand(1, 100) .'" class="symple-tabs">';
			$output .= '<ul class="ui-tabs-nav symple-clearfix">';
			foreach( $tab_titles as $tab ){
				$output .= '<li><a href="#symple-tab-'. sanitize_title( $tab[0] ) .'">' . $tab[0] . '</a></li>';
			}
		    $output .= '</ul>';
		    $output .= do_shortcode( $content );
		    $output .= '</div>';
		} else {
			$output .= do_shortcode( $content );
		}
		return $output;
	}
	add_shortcode( 'tgreen_tabgroup', 'tgreen_tabgroup_shortcode' );
}
if (!function_exists('tgreen_tab_shortcode')) {
	function tgreen_tab_shortcode( $atts, $content = null ) {
		$defaults = array(
			'title'			=> 'Tab',
			'class'			=> '',
			'visibility'	=> 'all',
		);
		extract( shortcode_atts( $defaults, $atts ) );
		return '<div id="symple-tab-'. sanitize_title( $title ) .'" class="tab-content '. $class .' symple-'. $visibility .'">'. do_shortcode( $content ) .'</div>';
	}
	add_shortcode( 'tgreen_tab', 'tgreen_tab_shortcode' );
}




/*
 * Pricing Table
 * @since v1.0
 *
 */
 
/*main*/
if( !function_exists('tgreen_pricing_table_shortcode') ) {
	function tgreen_pricing_table_shortcode( $atts, $content = null  ) {
		extract( shortcode_atts( array(
			'class'			=> '',
			'visibility'	=> 'all',
		), $atts ) );
		return '<div class="symple-pricing-table '. $class .' symple-'. $visibility .'">' . do_shortcode($content) . '</div><div class="symple-clear-floats"></div>';
	}
	add_shortcode( 'tgreen_pricing_table', 'tgreen_pricing_table_shortcode' );
}

/*section*/
if( !function_exists('tgreen_pricing_shortcode') ) {
	function tgreen_pricing_shortcode( $atts, $content = null  ) {
		
		extract( shortcode_atts( array(
			'size'					=> 'one-half',
			'position'				=> '',
			'featured'				=> 'no',
			'plan'					=> 'Basic',
			'cost'					=> '$20',
			'per'					=> 'month',
			'button_url'			=> '',
			'button_text'			=> 'Purchase',
			'button_color'			=> 'blue',
			'button_target'			=> 'self',
			'button_rel'			=> 'nofollow',
			'button_border_radius'	=> '',
			'class'					=> '',
		), $atts ) );
		
		//set variables
		$featured_pricing = ( $featured == 'yes' ) ? 'featured' : NULL;
		$border_radius_style = ( $button_border_radius ) ? 'style="border-radius:'. $button_border_radius .'"' : NULL;
		
		//start content  
		$pricing_content ='';
		$pricing_content .= '<div class="symple-pricing symple-'. $size .' '. $featured_pricing .' symple-column-'. $position. ' '. $class .'">';
			$pricing_content .= '<div class="symple-pricing-header">';
				$pricing_content .= '<h5>'. $plan. '</h5>';
				$pricing_content .= '<div class="symple-pricing-cost">'. $cost .'</div><div class="symple-pricing-per">'. $per .'</div>';
			$pricing_content .= '</div>';
			$pricing_content .= '<div class="symple-pricing-content">';
				$pricing_content .= ''. $content. '';
			$pricing_content .= '</div>';
			if( $button_url ) {
				$pricing_content .= '<div class="symple-pricing-button"><a href="'. $button_url .'" class="symple-button '. $button_color .'" target="_'. $button_target .'" rel="'. $button_rel .'" '. $border_radius_style .'><span class="symple-button-inner" '. $border_radius_style .'>'. $button_text .'</span></a></div>';
			}
		$pricing_content .= '</div>';  
		return $pricing_content;
	}
	
	add_shortcode( 'tgreen_pricing', 'tgreen_pricing_shortcode' );
}




/************************
 *
 * Version 1.1 Additions
 *
*************************/



/*
 * Heading
 * @since v1.1
 */
if( !function_exists('tgreen_heading_shortcode') ) {
	function tgreen_heading_shortcode( $atts ) {
		extract( shortcode_atts( array(
			'title'				=> __('Sample Heading', 'symple'),
			'type'				=> 'h2',
			'margin_top'		=> '',
			'margin_bottom'	=> '',
			'text_align'		=> '',
			'font_size'		=> '',
			'color'				=> '',
			'class'				=> '',
			'icon_left'		=> '',
			'icon_right'		=> '',
			'visibility'		=> 'all',
		  ),
		  $atts ) );
		  
		$style_attr = '';
		if ( $font_size ) {
			$style_attr .= 'font-size: '. $font_size .';';
		}
		if ( $color ) {
			$style_attr .= 'color: '. $color .';';
		}
		if( $margin_bottom ) {
			$style_attr .= 'margin-bottom: '. $margin_bottom .';';
		}
		if ( $margin_top ) {
			$style_attr .= 'margin-top: '. $margin_top .';';
		}
		
		if ( $text_align ) {
			$text_align = 'text-align-'. $text_align;
		} else {
			$text_align = 'text-align-left';
		}
		
	 	$output = '<'.$type.' class="symple-heading '. $text_align .' '. $class .' symple-'. $visibility .'" style="'.$style_attr.'"><span>';
		if ( $icon_left ) $output .= '<i class="symple-button-icon-left icon-'. $icon_left .'"></i>';
			$output .= $title;
		if ( $icon_right ) $output .= '<i class="symple-button-icon-right icon-'. $icon_right .'"></i>';
		$output .= '</span></'.$type.'>';
		
		return $output;
	}
	add_shortcode( 'tgreen_heading', 'tgreen_heading_shortcode' );
}


/*
 * Google Maps
 * @since v1.1
 */
if (! function_exists( 'tgreen_shortcode_googlemaps' ) ) :
	function tgreen_shortcode_googlemaps($atts, $content = null) {
		
		extract(shortcode_atts(array(
				'title'			=> '',
				'location'		=> '',
				'width'			=> '',
				'height'		=> '300',
				'zoom'			=> 8,
				'align'			=> '',
				'class'			=> '',
				'visibility'	=> 'all',
		), $atts));
		
		// load scripts
		wp_enqueue_script('symple_googlemap');
		wp_enqueue_script('symple_googlemap_api');
		
		
		$output = '<div id="map_canvas_'.rand(1, 100).'" class="googlemap '. $class .' symple-'. $visibility .'" style="height:'.$height.'px;width:100%">';
			$output .= (!empty($title)) ? '<input class="title" type="hidden" value="'.$title.'" />' : '';
			$output .= '<input class="location" type="hidden" value="'.$location.'" />';
			$output .= '<input class="zoom" type="hidden" value="'.$zoom.'" />';
			$output .= '<div class="map_canvas"></div>';
		$output .= '</div>';
		
		return $output;
	   
	}
	add_shortcode("tgreen_googlemap", "tgreen_shortcode_googlemaps");
endif;


/*
 * Divider
 * @since v1.1
 */
if( !function_exists('tgreen_divider_shortcode') ) {
	function tgreen_divider_shortcode( $atts ) {
		extract( shortcode_atts( array(
			'style'				=> 'fadeout',
			'margin_top'		=> '20px',
			'margin_bottom'	=> '20px',
			'class'				=> '',
			'visibility'		=> 'all',
		  ),
		  $atts ) );
		$style_attr = '';
		if ( $margin_top && $margin_bottom ) {  
			$style_attr = 'style="margin-top: '. $margin_top .';margin-bottom: '. $margin_bottom .';"';
		} elseif( $margin_bottom ) {
			$style_attr = 'style="margin-bottom: '. $margin_bottom .';"';
		} elseif ( $margin_top ) {
			$style_attr = 'style="margin-top: '. $margin_top .';"';
		} else {
			$style_attr = NULL;
		}
	 return '<hr class="symple-divider '. $style .' '. $class .' symple-'. $visibility .'" '.$style_attr.' />';
	}
	add_shortcode( 'tgreen_divider', 'tgreen_divider_shortcode' );
}