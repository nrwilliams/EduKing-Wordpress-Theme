<?php

/*
 * Plugin Name: Showoff
 * Description: Showoff version 1.06 Plugin
 * Author: Eightyclouds
 * Version: 1.06
 * Author URI: http://eightyclouds.com
 */

defined("DS")            ? NULL : define("DS", DIRECTORY_SEPARATOR);
defined("SHOWOFF_FILE")  ? NULL : define("SHOWOFF_FILE", __FILE__);

/******************************************************
 * Require showoff class
 ******************************************************/
require_once(dirname(__FILE__) . DS . "admin" . DS . "class" . DS . "showoff.php");







/******************************************************
 * Language
 ******************************************************/
load_plugin_textdomain('showoff', false, basename( dirname( __FILE__ ) ) . '/language' );



/******************************************************
 * INSTALLATION
 ******************************************************/

/* Install */
function showoff_activate() {
    require_once(dirname(__FILE__) . DS . "install.php");
}
register_activation_hook(__FILE__, "showoff_activate");

/* Uninstall */
function showoff_uninstall() {
    require_once(dirname(__FILE__) . DS . "uninstall.php");
}
register_uninstall_hook(__FILE__, "showoff_uninstall");




    
    



/******************************************************
 * Styles & Scripts
 ******************************************************/

function showoff_load_admin_styles() {
    wp_enqueue_media();
    wp_enqueue_style("showoff-admin-style", plugins_url( 'admin/css/style.css', __FILE__ ));
    wp_enqueue_style("showoff-admin-style-colorpicker", plugins_url( 'admin/js/colorpicker/css/colorpicker.css', __FILE__ ));
    wp_enqueue_script("showoff-admin-js", plugins_url( 'admin/js/showoff.js', __FILE__ ), array("jquery"));
    wp_enqueue_script("showoff-admin-js-colorpicker", plugins_url( 'admin/js/colorpicker/js/colorpicker.js', __FILE__ ), array("jquery"));
}









/******************************************************
 * ADMIN MENUS 
 ******************************************************/

/* Register Admin Menu */
function register_showoff_admin_menu_page() {
   $page = 'showoff/admin/view/home/index.php';
   
   global $wp_version;
   
   $ico = $wp_version >= 3.8 ? "dashicons-screenoptions" : plugins_url("admin/img/admin_ico.png", __FILE__);
   
   add_utility_page('showoff', 'Showoff', 'add_users', $page, '',   $ico, 6);
   add_action('admin_print_styles-'. $page, 'showoff_load_admin_styles');
}
add_action('admin_menu', 'register_showoff_admin_menu_page');

/* General sub-menu */
function register_showoff_admin_submenu_page_general() {
    $page = 'showoff/admin/view/general/index.php';
    add_submenu_page('showoff/admin/view/home/index.php', 'Showoff - General', 'General', 'add_users', $page);
    add_action('admin_print_styles-'  . $page, 'showoff_load_admin_styles');
}
add_action('admin_menu', 'register_showoff_admin_submenu_page_general');

/* Categories sub-menu */
function register_showoff_admin_submenu_page_categories() {
    $page = 'showoff/admin/view/categories/index.php';
    add_submenu_page('showoff/admin/view/home/index.php', 'Showoff - Categories', 'Categories', 'add_users', $page);
    add_action('admin_print_styles-'  . $page, 'showoff_load_admin_styles');
}
add_action('admin_menu', 'register_showoff_admin_submenu_page_categories');

/* Projects sub-menu */
function register_showoff_admin_submenu_page_projects() {
    $page = 'showoff/admin/view/projects/index.php';
    add_submenu_page('showoff/admin/view/home/index.php', 'Showoff - Projects', 'Projects', 'add_users', $page);
    add_action('admin_print_styles-'  . $page, 'showoff_load_admin_styles');
}
add_action('admin_menu', 'register_showoff_admin_submenu_page_projects');










/******************************************************
 * AJAX handling
 ******************************************************/

function showoff_ajaxurl() {
?>
    <script type="text/javascript">
        if (typeof ajaxurl === "undefined") 
        var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
    </script>
<?php
}
add_action('wp_head', 'showoff_ajaxurl');



function showoff_getProjects() {
    require(dirname(__FILE__) . DS . "site" . DS . "view" . DS . "ajax.php");
    die();
}
add_action('wp_ajax_nopriv_showoff_getProjects', 'showoff_getProjects');
add_action('wp_ajax_showoff_getProjects', 'showoff_getProjects');



function showoff_orderProjects() {
    showoff::order_projects();
    die();
}
add_action('wp_ajax_nopriv_showoff_orderProjects', 'showoff_orderProjects');
add_action('wp_ajax_showoff_orderProjects', 'showoff_orderProjects');








/******************************************************
 * Check for Shortcode
 ******************************************************/

function showoff_check_for_shortcode() {
    global $post;
    if (has_shortcode($post->post_content, 'showoff')) {
        showoff::load_scripts();
    }
}

add_action('wp_enqueue_scripts', 'showoff_check_for_shortcode');





/******************************************************
 * Display Front-End
 ******************************************************/
function showoff_display($args = array()) {
    
    ob_start();
    
    $options = showoff::get_options();
    $options->unique = showoff::unique();
    
    $options->_get_project = (int) showoff::REQUEST("showoff_project", "get", 0);
    $options->_get_page    = (int) showoff::REQUEST("showoff_page", "get", 0);
    $options->_get_cat     = (int) showoff::REQUEST("showoff_cat", "get", 0);
    
    if (!empty($args)) {
        foreach ($args as $key => $arg) {
            $options->{$key} = $arg;
        }
    }
    
    showoff::set_options($options);
    
    showoff::load_scripts();
    
    showoff::register_js_instance();
    
    showoff::custom_css_style();
    
    require(dirname(__FILE__) . DS . "site" . DS . "view" . DS . "display.php");
    
    showoff::clear_options();
    
    return ob_get_clean();
    
}
add_shortcode("showoff", "showoff_display");