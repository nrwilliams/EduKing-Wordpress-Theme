<div class="showoff" id="<?php echo $options->unique; ?>">
    
    <div class="showoff-top">
        <p class="showoff-top-title"><?php echo $options->title; ?></p>
        <div class="showoff-categories">
            <?php $categories = showoff::front_get_categories(); ?>
            
            <a id="showoff-cat-0" href="#" class="active"><?php _e("All","showoff"); ?></a>

            <?php foreach ($categories as $category) : ?>
                <a id="showoff-cat-<?php echo $category->id; ?>" href="#"><?php echo $category->title; ?></a>
            <?php endforeach; ?>
        </div>
        
        <select class="showoff-categories-mini">
            <option value="showoff-cat-0"><?php _e("All","showoff"); ?></option>
            <?php foreach ($categories as $category) : ?>
                <option value="showoff-cat-<?php echo $category->id; ?>"><?php echo $category->title; ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="showoff-content">
        <ul>
           <?php 
                $perpage = $options->perpage;
                while ($perpage > 0) :
                ?><li><div class="showoff-project-thumbnail"></div></li><?php
                    $perpage--;
                endwhile;
           ?>
        </ul>
    </div>
    
    <div class="showoff-pagination"></div>
    
</div>