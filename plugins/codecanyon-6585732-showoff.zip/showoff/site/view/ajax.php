<?php 
$projects = showoff::front_get_projects(); 
$projecthoverstyle = showoff::get_option("projecthoverstyle", "title");

$json = array();
ob_start();
?>
<ul>
    <?php foreach ($projects as $project) : ?>
        <li class="showoff-project-id-<?php echo $project->id; ?> showoff-project-cat-<?php echo str_replace(",","-",$project->catid); ?>">
            
            <div class="showoff-project-thumbnail">
                <?php if ($project->thumbnail != "") : echo "<img src='{$project->thumbnail}' />"; endif; ?>
                
                <div class="showoff-project-thumbnail-hover">
                    <div class="showoff-project-thumbnail-hover-style">
                        <?php if ($projecthoverstyle === "title") : ?>
                            <i class="titlestyle fa fa-eye"></i>
                            <p><?php echo $project->title; ?></p>
                        <?php else: ?>
                            <i class="fa fa-eye"></i>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="showoff-project-inner">
                <div class="showoff-project-inner-wrapper">
                    
                    <div class="fa fa-times showoff-project-inner-close"></div>
                    <?php $images = explode("||",$project->image); ?>
                    <?php $images = array_filter( $images, 'strlen' ); ?>
                    
                        <?php if (!empty($images) && $images[0] != "" && $project->content != "") : ?>
                            <!-- Images and Content -->
                            <div class="showoff-project-inner-left">
                                <div class="showoff-project-inner-media">
                                    <?php foreach ($images as $k => $image) : ?>
                                        <img style="display:none" src="" alt="<?php echo $image; ?>" />
                                    <?php endforeach; ?>

                                    <div class="showoff-project-inner-media-loader"></div>

                                    <?php if (count($images) > 1) : ?>
                                    <div class="showoff-project-inner-pagination">
                                        <?php foreach ($images as $k => $i) : ?>
                                            <div class="fa fa-circle showoff-project-inner-pagination-page <?php if ($k == 0) echo "active"; ?>"></div>
                                        <?php endforeach; ?>
                                    </div>
                                    <?php endif;?>
                                </div>
                            </div>
                            
                            <div class="showoff-project-inner-right">
                                <h4><?php echo $project->title; ?></h4>
                                <div class="showoff-project-inner-content"><?php echo do_shortcode($project->content); ?></div>
                                <?php if ($project->readmore != "") : ?>
                                    <a target="_BLANK" class="showoff-project-inner-readmore" href="<?php echo $project->readmore; ?>"><?php _e("Read more","showoff"); ?></a>
                                <?php endif; ?>
                            </div>
                    
                        <?php elseif(!empty($images) && $images[0] != "" && $project->content == ""): ?>
                            
                            <!-- Images Only -->
                            <div class="showoff-project-inner-full">
                                <h4><?php echo $project->title; ?></h4>
                                <div class="showoff-project-inner-media">
                                    <?php foreach ($images as $k => $image) : ?>
                                        <img style="display:none" src="" alt="<?php echo $image; ?>" />
                                    <?php endforeach; ?>

                                    <div class="showoff-project-inner-media-loader"></div>

                                    <?php if (count($images) > 1) : ?>
                                    <div class="showoff-project-inner-pagination">
                                        <?php foreach ($images as $k => $i) : ?>
                                            <div class="fa fa-circle showoff-project-inner-pagination-page <?php if ($k == 0) echo "active"; ?>"></div>
                                        <?php endforeach; ?>
                                    </div>
                                    <?php endif;?>
                                </div>
                                
                                <?php if ($project->readmore != "") : ?>
                                    <a target="_BLANK" class="showoff-project-inner-readmore" href="<?php echo $project->readmore; ?>"><?php _e("Read more","showoff"); ?></a>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <!-- Content Only -->
                            <div class="showoff-project-inner-full">
                                <h4><?php echo $project->title; ?></h4>
                                <div class="showoff-project-inner-content"><?php echo do_shortcode($project->content); ?></div>
                                <?php if ($project->readmore != "") : ?>
                                    <a target="_BLANK" class="showoff-project-inner-readmore" href="<?php echo $project->readmore; ?>"><?php _e("Read more","showoff"); ?></a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                </div>
            </div>
        </li>
    <?php endforeach; ?>
</ul>
<?php $json["html"] = ob_get_clean(); ?>
 
<?php ob_start(); ?>
<div class="showoff-pagination">
    <?php $pages = showoff::front_get_pagination(); ?> 
    <?php
    $page = (int) showoff::REQUEST("page", "post");
    if ($page === 0)
        $page = 1;
    ?>
    <?php if ($pages > 1) : ?>
        <?php for ($i = 1; $i <= $pages; $i++) : ?>
            <a id="showoff-page-<?php echo $i; ?>" class="<?php if ($i === $page) echo "active" ?>" href="#"><?php echo $i; ?></a>
        <?php endfor; ?>
<?php endif; ?>
</div>
<?php $json["pages"] = ob_get_clean(); ?>

<?php    
    $json = json_encode($json);
    echo $json;
?>