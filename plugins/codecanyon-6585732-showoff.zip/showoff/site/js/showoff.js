function showoff() {

    "use strict";

    var glob = {
        options: "",
        instance: "",
        page: "1",
        cat: "0"
    };

    this.init = function(options) {
        glob.instance = "#" + options.unique;
        glob.options = options;
        
        // Append the style to the header
        jQuery(glob.instance).prev("style").appendTo("head");
        
        // Check _GET_CAT
        if (glob.options._get_cat) {
            
            if (glob.options.catfilter === "standard") {
                glob.cat = glob.options._get_cat;
            }
            
            projects.categories.active = glob.options._get_cat;
            
            jQuery(glob.instance).find(".showoff-categories a").removeClass("active");
            jQuery(glob.instance).find(".showoff-categories a").eq(glob.options._get_cat).addClass("active");
            jQuery(glob.instance).find(".showoff-categories-mini").children().eq(glob.options._get_cat).prop("selected",true);
        }
        
        // Check _GET_PAGE
        if (glob.options._get_page) {
            glob.page = glob.options._get_page;
            projects.pagination.active = glob.options._get_page;
        }
        
        projects.init();
        lightbox.init();
        
        if (helper.isModern() === true && glob.options.projecthovertype === "modern") {
            modernHover.init();
        } else {
            jQuery(glob.instance).addClass("legacy");
        }
        
        jQuery(glob.instance).show();
    };
    
    var helper = {
        
        focus: function(el) {
            jQuery('html, body').animate({
                scrollTop: jQuery(el).offset().top - jQuery("#wpadminbar").height() + parseInt(glob.options.focusoffset,10)
            }, {
                duration: 750,
                easing: "easeInOutExpo"
            });
        },
        
        isModern: function() {
            return Modernizr.cssanimations;
        },
                
        mediaQuery: function() {
    
            if (jQuery(glob.instance).width() <= 320) {
                projects.cols = 1;
            } else {
                projects.cols = glob.options.cols;
            }
            
            if (jQuery(glob.instance).width() <= 640 && jQuery(glob.instance).width() > 320) {
                jQuery(glob.instance).find(".showoff-project-thumbnail-hover-style p").addClass("mini");
            } else {
                jQuery(glob.instance).find(".showoff-project-thumbnail-hover-style p").removeClass("mini");
            }
            
            if (jQuery(glob.instance).width() <= 768) {
                jQuery(glob.instance).find(".showoff-project-inner-right").addClass("mini");
                jQuery(glob.instance).find(".showoff-project-inner-left").addClass("mini");
                jQuery(glob.instance).find(".showoff-pagination").addClass("mini");
                jQuery(glob.instance).find(".showoff-top").addClass("mini");
                
                if (jQuery(glob.instance).find(".showoff-categories a").length > 2) {
                    jQuery(glob.instance).find(".showoff-categories-mini").show();
                    jQuery(glob.instance).find(".showoff-categories").hide();
                }
            } else {
                jQuery(glob.instance).find(".showoff-project-inner-left").removeClass("mini");
                jQuery(glob.instance).find(".showoff-project-inner-right").removeClass("mini");
                jQuery(glob.instance).find(".showoff-pagination").removeClass("mini");
                jQuery(glob.instance).find(".showoff-top").removeClass("mini");
                
                if (jQuery(glob.instance).find(".showoff-categories a").length > 2) {
                    jQuery(glob.instance).find(".showoff-categories-mini").hide();
                    jQuery(glob.instance).find(".showoff-categories").show();
                }
            }
        }
    };

    var modernHover = {
        init: function() {
            this.bindControls();
        },
        bindControls: function() {
            jQuery(glob.instance).find("li").on("mouseenter", function(ev) {
                modernHover.addClass(ev, this, 'in');
            });

            jQuery(glob.instance).find("li").on("mouseleave", function(ev) {
                modernHover.addClass(ev, this, 'out');
            });
        },
        clearClasses: function(obj){
            jQuery(obj).removeClass("in-top in-right in-bottom in-left out-top out-right out-bottom out-left");
        },
        direction: function(ev, obj) {
            var w = jQuery(obj).width(),
                    h = jQuery(obj).height(),
                    x = (ev.pageX - jQuery(obj).offset().left - (w / 2) * (w > h ? (h / w) : 1)),
                    y = (ev.pageY - jQuery(obj).offset().top - (h / 2) * (h > w ? (w / h) : 1)),
                    d = Math.round(Math.atan2(y, x) / 1.57079633 + 5) % 4;

            return d;
        },
        addClass: function(ev, obj, state) {
            var direction = modernHover.direction(ev, obj), class_suffix = "";

            modernHover.clearClasses(obj);

            switch (direction) {
                case 0 :
                    class_suffix = '-top';
                    break;
                case 1 :
                    class_suffix = '-right';
                    break;
                case 2 :
                    class_suffix = '-bottom';
                    break;
                case 3 :
                    class_suffix = '-left';
                    break;
            }

            jQuery(obj).addClass(state + class_suffix);
        }
    };

    var ajax = {
        request: null,
        getProjects: function() {
            
            if (glob.cat === "0") {
                var allcats = [];
                jQuery(glob.instance).find(".showoff-categories a:gt(0)").each(function(i) {
                    allcats[i] = jQuery(this).attr("id").replace("showoff-cat-", "");
                });
                glob.cat = allcats.join(",");
            }

            var data = {
                action: "showoff_getProjects",
                page: glob.page,
                cat: glob.cat,
                perpage: glob.options.perpage
            };

            ajax.request = jQuery.ajax({
                type: "POST",
                url: ajaxurl,
                data: data,
                dataType: "json",
                beforeSend: function() {
                    if (ajax.request)
                        ajax.request.abort();
                    jQuery(glob.instance).find(".showoff-content > ul > li").removeClass("inactive");
                },
                success: function(data) {
                    projects.swap(data);
                },
                error: function(xhr, status, thrown) {
                    console.log(xhr + " " + status + " " + thrown);
                },
                complete: function() {
                    ajax.request = null;
                }
            });
        }
    };
    
    var lightbox = {
        
        images: false,
        imageIndex: false,
        
        init: function(){
          this.bindControls();  
        },
                
        bindControls: function(){
            
            /* Image lightbox */
            jQuery(document).on("click", glob.instance + " .showoff-project-inner-media img", function(event){
                event.stopPropagation();
                if (glob.options.lightbox == "1") {
                    lightbox.show(this);
                }
            });
    
            jQuery(document).on("click", ".showoff-blackbox", function(){
                lightbox.hide();
            });
    
            jQuery(document).on("click", ".showoff-lightbox-close", function(){
                lightbox.hide();
            });
            
            jQuery(document).on("click", ".showoff-lightbox-navigation-right", function(event){
                event.preventDefault();
                lightbox.navigateTo("next");
            });
            
            jQuery(document).on("click", ".showoff-lightbox-navigation-left", function(event){
                event.preventDefault();
                lightbox.navigateTo("prev");
            });
            
            jQuery(document).on("keyup", function(event) {
                if (jQuery(".showoff-lightbox").length <= 0) {
                    return;
                };
                
                if (event.which === 37) {
                    lightbox.navigateTo("prev");
                }
                
                if (event.which === 39) {
                    lightbox.navigateTo("next");
                }
                
                if (event.which === 27) {
                    lightbox.hide();
                }
            });
            
            jQuery(window).resize(function(){
                lightbox.dimensions();
            });
        },
        
        dimensions: function() {
            jQuery(".showoff-lightbox img").css({
                maxWidth: jQuery(window).width() - 40,
                maxHeight: jQuery(window).height() - 180 > 150 ? jQuery(window).height() - 180 : 150
            });
            
            jQuery(".showoff-lightbox").css({
                top: jQuery(window).height() / 2 - jQuery(".showoff-lightbox").outerHeight() / 2,
                left: jQuery(window).width() / 2 - jQuery(".showoff-lightbox").outerWidth() / 2
            });
        },
        
        navigateTo: function(dir) {
            switch (dir) {
                case "next" :
                    lightbox.imageIndex++; 
                    
                    if (lightbox.imageIndex > lightbox.images.length - 1) {
                        lightbox.imageIndex = 0;
                    }
                break;
                
                case "prev" :
                    lightbox.imageIndex--;
                    
                    if (lightbox.imageIndex < 0) {
                        lightbox.imageIndex = lightbox.images.length - 1;
                    }
                break;
            }
            
            var src = jQuery(lightbox.images[lightbox.imageIndex]).attr("alt");
            var img = jQuery(".showoff-lightbox img");
            
            jQuery(".showoff-lightbox").addClass("loading");
            
            img.fadeTo(250, 0, function() {
                jQuery(".showoff-lightbox").css({
                    width: img.width(),
                    height: img.height(),
                    minWidth: 260
                });
                
                img.attr("src", "");
                
                img.attr("src", src);
                
                img.imagesLoaded(function() {
                    
                    jQuery(".showoff-lightbox").removeClass("loading");
                    
                    jQuery(".showoff-lightbox").stop().animate({
                        width: img.width()
                    }, {
                        easing: "easeOutExpo",
                        duration: 250,
                        step: function() {
                            lightbox.dimensions();
                        },
                                
                        complete: function(){
                            jQuery(".showoff-lightbox").css({
                                width: "auto",
                                height: "auto"
                            });

                            img.fadeTo(250, 1);
                            lightbox.dimensions();
                        }
                    });
                    
                    
                });
            });
            
            jQuery(".showoff-lightbox-share.facebook_icon").attr("href", "http://www.facebook.com/share.php?u=" + src);
            jQuery(".showoff-lightbox-share.twitter_icon").attr("href", "http://twitter.com/home?status=" + src);
            jQuery(".showoff-lightbox-share.googleplus_icon").attr("href", "https://plus.google.com/share?url=" + src);
            jQuery(".showoff-lightbox-share.pinit_icon").attr("href", "http://www.pinterest.com/pin/create/button/?url="+src+"&amp;media="+src+"&amp;description");
        },
        
        show: function(el){
            lightbox.hide();
            
            var project = jQuery(el).parents("li");
            
            lightbox.images = project.find(".showoff-project-inner-media img");
            lightbox.imageIndex  = jQuery(el).index();
            
            jQuery('<div class="showoff-blackbox"></div>').appendTo('body').each(function(){
                jQuery(this).css("opacity","0.1").fadeTo(250,0.7)
            });
            
            var src = jQuery(lightbox.images[lightbox.imageIndex]).attr("alt");
            
            var html  = '<div class="showoff-lightbox">';
                html += '   <div class="fa fa-times showoff-lightbox-close"></div>';
                
                html += '   <img src="'+src+'" />';
                
                html += '   <div class="showoff-lightbox-navigation">';
                html += '       <a href="#" class="showoff-lightbox-navigation-left"><i class="fa fa-chevron-left"></i></a>';
                html += '       <a href="#" class="showoff-lightbox-navigation-right"><i class="fa fa-chevron-right"></i></a>';
                html += '   </div>';
                
                if (glob.options.sharebuttons == "1") {
                    html += '   <div class="showoff-lightbox-share-buttons">';
                    html += '       <a target="_BLANK" class="showoff-lightbox-share googleplus_icon" href="https://plus.google.com/share?url='+src+'"></a>';
                    html += '       <a target="_BLANK" class="showoff-lightbox-share twitter_icon" href="http://twitter.com/home?status='+src+'"></a>';
                    html += '       <a target="_BLANK" class="showoff-lightbox-share facebook_icon" href="http://www.facebook.com/share.php?u='+src+'"></a>';
                    html += '       <a target="_BLANK" class="showoff-lightbox-share pinit_icon" href="http://www.pinterest.com/pin/create/button/?url='+src+'&amp;media='+src+'&amp;description"></a>';
                    html += '   </div>';
                }
                
                html += '</div>';
                
                
            jQuery(html).fadeTo(0,0).appendTo('body');
            
            if (glob.options.sharebuttons == "0") {
                jQuery(".showoff-lightbox").css({
                   paddingBottom: jQuery(".showoff-lightbox").css("paddingTop")
                });
            }
            
            jQuery(".showoff-lightbox img").imagesLoaded(function(){
                jQuery(".showoff-lightbox").fadeTo(250,1);
                lightbox.dimensions();
            });
            
        },
                
        hide: function(){
            jQuery(".showoff-lightbox").remove();
            jQuery(".showoff-blackbox").fadeOut(250, function(){
                jQuery(this).remove();
                lightbox.images = false;
                lightbox.imageIndex = false;
            });
        }
    };
    
    var projects = {
        swapping: true,
        cols: 4,
        spacing: 1,
        aspect: 1,
        li: "",
        init: function() {
            
            if (jQuery(glob.instance).find(".showoff-categories a").length <= 2) {
                jQuery(glob.instance).find(".showoff-categories").hide();
            }
    
            projects.li = jQuery(glob.instance).find(".showoff-content > ul > li");

            projects.spacing = glob.options.spacing;
            projects.aspect  = glob.options.aspect;
            
            jQuery(glob.instance).find(".showoff-top").css({
               marginLeft: projects.spacing / 2 + "%",
               marginRight: projects.spacing / 2 + "%",
               width: 100 - projects.spacing + "%"
            });
            
            jQuery(glob.instance).find(".showoff-pagination").css({
               marginLeft: projects.spacing / 2 + "%",
               marginRight: projects.spacing / 2 + "%"
            });
            
            ajax.getProjects();

            projects.bindControls();

        },
        bindControls: function() {
            
            /* Inner media arrow navigation */
            jQuery(document).on("keyup", function(event) {
                if (jQuery(".showoff-lightbox").length <= 0 && jQuery(glob.instance).find(".showoff-content > ul > li").hasClass("active")) {
                    var $project  = jQuery(glob.instance).find(".showoff-content > ul > li.active");
                    var $pages    = $project.find(".showoff-project-inner-pagination-page");
                    var $active   = $project.find(".showoff-project-inner-pagination-page.active");
                    
                    if (event.which === 37) {
                        var $index = $active.index() - 1 < 0 ? $pages.length - 1 : $active.index() - 1;
                        var $prev = $pages.eq($index);
                        projects.inner.pagination.paginate($prev);
                    }

                    if (event.which === 39) {
                        var $index = $active.index() + 1 > $pages.length - 1 ? 0 : $active.index() + 1;
                        var $next = $pages.eq($index);
                        projects.inner.pagination.paginate($next);
                    }
                }
            });
            
            
            /* Project Click */
            jQuery(document).on("click", glob.instance + " .showoff-content > ul > li", function() {
                projects.inner.show(this);
            });
            
            jQuery(document).on("click", glob.instance + " .showoff-project-inner", function(event){
                event.stopPropagation();
            });

            /* Pagination Click */
            jQuery(document).on("click", glob.instance + " .showoff-pagination a", function(event) {
                event.preventDefault();
                if (projects.swapping === true) return;
                projects.pagination.set(this);
            });

            /* Categories Click */
            jQuery(document).on("click", glob.instance + " .showoff-categories a", function(event) {
                event.preventDefault();
                if (projects.swapping === true) return;
                projects.categories.set(this);
            });

            /* Categories Mini Selector */
            jQuery(document).on("change", glob.instance + " .showoff-categories-mini", function(event) {
                event.preventDefault();
                if (projects.swapping === true) {
                    jQuery(glob.instance).find(".showoff-categories-mini").val(jQuery(glob.instance + " .showoff-categories a.active").attr("id"));
                    return;
                };
                projects.categories.set(this);
            });

            /* On Resize */
            jQuery(window).resize(function() {
                projects.resize();
            });
            
            /* Inner pagination */
            jQuery(document).on("click", glob.instance + " .showoff-project-inner-pagination-page", function(event) {
                event.preventDefault();
                event.stopPropagation();
                projects.inner.pagination.paginate(this);
            });
            
            /* Inner close button */
            jQuery(document).on("click", glob.instance + " .showoff-project-inner-close", function(event) {
                event.preventDefault();
                event.stopPropagation();
                projects.inner.hide();
                helper.focus(glob.instance);
            });
        },
        resize: function() {

            helper.mediaQuery();

            // Dimensions ( false - all instance elements, false - do not hide actives 
            projects.dimensions(false, false);
            projects.inner.position();
        },
                
        dimensions: function(li, slideUp) {
            var $li = li ? li : projects.li;

            /* Hide inner content, no animation */
            if (slideUp) {
                $li.find(".showoff-project-inner").slideUp(0);
            }
            
            /* Adjust width, height and spacing */
            $li.each(function() {
                jQuery(this).css({
                    margin: (projects.spacing / 2) + "%",
                    width: 100 / projects.cols - projects.spacing + "%"
                });
                
                var y1 = jQuery(this).width() / projects.aspect;
                jQuery(this).height(y1);
                jQuery(this).find(".showoff-project-thumbnail").height(y1 + 1);
                jQuery(this).find(".showoff-project-thumbnail img").height(y1);
            });
        },
        inner: {
            /* Slide Up and Down Speed */
            speed: 250,
            /* Slide Up and Down Easing */
            easing: "easeInOutExpo",
                    
            pagination: {
                paginate: function(el) {
                    var page = jQuery(el);
                    if (page.hasClass("active")) return;
                    
                    page.siblings().removeClass("active");
                    page.addClass("active");
                    
                    var loader = page.parents("li").find(".showoff-project-inner-media-loader");
                    var inner = page.parents('.showoff-project-inner-media');
                    var img = inner.find("img").eq(page.index());
                    var src = img.attr("alt");
                    img.attr("src",src);
                    
                    loader.css({
                        height: inner.find("img:visible").height()
                    });
                    
                    inner.find("img").hide();
                    
                    loader.show();
                    
                    img.imagesLoaded(function(){
                        loader.hide();
                        img.fadeTo(250,1);
                        projects.inner.position(page.parents("li"));
                    });
                    
                    
                }
            },
            
            position: function(sel) {
                sel = sel ? sel : projects.li;
                
                jQuery(sel).each(function() {
                    if (jQuery(this).hasClass("active")) {

                        // Thumb Opened

                        var y1 = jQuery(this).width() / projects.aspect;
                        var y2 = jQuery(this).find(".showoff-project-inner").height();

                        jQuery(this).height(y1 + y2);
                        jQuery(this).find(".showoff-project-thumbnail").height(y1 + 1);
                        jQuery(this).find(".showoff-project-thumbnail img").height(y1);

                        // Inner

                        var y1 = jQuery(this).position().top;
                        var y2 = jQuery(this).width() / projects.aspect;
                        var y3 = jQuery(this).outerWidth(true) - jQuery(this).innerWidth();

                        jQuery(this).find(".showoff-project-inner").css({
                            top: y1 + y2 + y3,
                            left: 0
                        });

                    } else {

                        // Thumb Closed

                        var y1 = jQuery(this).width() / projects.aspect;
                        jQuery(this).height(y1);
                        jQuery(this).find(".showoff-project-thumbnail").height(y1 + 1);
                        jQuery(this).find(".showoff-project-thumbnail img").height(y1);
                    }
                });
            },
            hide: function(callback) {

                // Hide opened
                jQuery(glob.instance).find(".showoff-content > ul > li.active").each(function(i) {
                    
                    jQuery(this).removeClass("active");
                    jQuery(this).stop().animate({
                        height: jQuery(this).width() / projects.aspect
                    }, {
                        start: function() {
                            jQuery(this).find(".showoff-project-inner").stop().slideUp({
                                duration: projects.inner.speed,
                                easing: projects.inner.easing
                            });
                        },
                        duration: projects.inner.speed,
                        easing: projects.inner.easing
                    });
                });
                
                if (typeof callback === "function") {
                    setTimeout(function() {
                        callback.call();
                    }, projects.inner.speed + 10);
                } 
            },
            show: function(sel) {
                // Do nothing if inactive, animating, swapping or empty
                if (jQuery(sel).hasClass("inactive") || projects.li.is(":animated") || projects.swapping === true || jQuery(sel).find(".showoff-project-inner").length <= 0) return;

                var $li = jQuery(sel);
                var $inner = $li.find(".showoff-project-inner");

                // Hide if this is active 
                if ($li.hasClass("active")) {
                    projects.inner.hide();
                    return;
                }
                
                var show = function() {
                    
                    // Set this to active
                    $li.addClass("active");
                    
                    // Adjusting some spacing to fit nicely
                    $li.find(".showoff-project-inner-wrapper").css({
                        marginTop: projects.spacing / 2 + "%",
                        marginBottom: projects.spacing / 2 + "%",
                        marginLeft: projects.spacing / 2 + "%",
                        width: (100 - projects.spacing) + "%"
                    });
                    
                    helper.mediaQuery();
                    
                    var page   = $li.find(".showoff-project-inner-pagination-page.active");
                    var img    = $li.find(".showoff-project-inner-media img").eq(page.index());
                    var loader = $li.find(".showoff-project-inner-media-loader");
                    
                    // Do animation
                    $li.stop().animate({
                        height: $li.width() + $inner.height()
                    }, {
                        start: function() {
                            $inner.stop().hide().slideDown({
                                duration: projects.inner.speed,
                                easing: projects.inner.easing
                            });
                            
                            if (img.is(":hidden")) {
                                loader.css({
                                    height: $li.find(".showoff-project-inner-right").height() - $li.find(".showoff-project-inner-pagination").outerHeight(true)
                                }).show();
                            }
                            
                            projects.inner.position($li);
                            
                        },
                                
                        complete: function() {
                    
                            if (img.is(":hidden")) {
                                img.attr("src",img.attr("alt"));
                                img.imagesLoaded(function(){
                                   loader.hide();
                                   img.fadeTo(250,1);
                                   projects.inner.position($li);
                                });
                            }
                            
                            helper.focus($li.find(".showoff-project-inner"));
                        },
                                
                        duration: projects.inner.speed,
                        easing: projects.inner.easing
                    });
                };

                // Check open
                if ($li.siblings().hasClass("active")) {
                    projects.inner.hide(function() {
                        show();
                    });
                } else {
                    show();
                }
            }
        },
        swapAnimation: function() {
            if (helper.isModern() === false) {
                
                jQuery(glob.instance).find(".showoff-project-thumbnail img").css({
                    position: "absolute"
                });
                
                projects.li.each(function(i) {
                    var $oldthumb = jQuery(this).find(".showoff-project-thumbnail img.old");
                    var $newthumb = jQuery(this).find(".showoff-project-thumbnail img.new");
                  
                    $oldthumb.css({zIndex: 1}).delay(((i + 1) * 100) ).fadeTo(250,0);
                    $newthumb.css({zIndex: 0}).delay(((i + 1) * 100) ).fadeTo(250,1);
                });
                var animationDuration = 250;
                // Animations complete
                setTimeout(function() {
                    projects.li.each(function() {
                        jQuery(this).removeClass("animate-3d");
                        jQuery(this).find(".showoff-project-thumbnail img.old").remove();
                        jQuery(this).find(".showoff-project-thumbnail img.new").attr("class", "");

                        if (jQuery(this).find(".showoff-project-inner").length <= 0) {
                            jQuery(this).hide();
                        }

                        projects.categories.filter();
                    });
                    projects.swapping = false;
                }, projects.li.length * 100 + animationDuration);
                return;
            }
            
            var liZindex = projects.li.length;
            projects.li.find(".showoff-project-thumbnail").each(function(i) {
                jQuery(this).css({
                    zIndex: liZindex - i
                });
            });
            
            switch (glob.options.animationtype) {
                
                case "falldown_scaleup" :
                    
                    projects.li.each(function(i) {
                        var $oldthumb = jQuery(this).find(".showoff-project-thumbnail img.old");
                        var $newthumb = jQuery(this).find(".showoff-project-thumbnail img.new");
                        // Set animation delay
                        jQuery(this).find(".showoff-project-thumbnail img").css({
                            "animation-delay": ((i + 1) * 100) + "ms"
                        });
                        // Run css animations
                        $oldthumb.css({zIndex: 1}).addClass("animate-fallDown");
                        $newthumb.css({zIndex: 0}).addClass("animate-scaleUp");
                    });
                    break;
                
                case "fallrotate_fadein" :
                    jQuery(projects.li.get().reverse()).each(function(i) {
                        var $oldthumb = jQuery(this).find(".showoff-project-thumbnail img.old");
                        var $newthumb = jQuery(this).find(".showoff-project-thumbnail img.new");
                        // Set animation delay
                        jQuery(this).find(".showoff-project-thumbnail img").css({
                            "animation-delay": ((i + 1) * 100) + "ms"
                        });
                        // Run css animations
                        $oldthumb.css({zIndex: 1}).addClass("animate-fallRotate");
                        $newthumb.css({zIndex: 0}).addClass("animate-fadeIn");
                    });
                break;
                
                case "rotate_scale" :
                    projects.li.each(function(i) {
                        var $oldthumb = jQuery(this).find(".showoff-project-thumbnail img.old");
                        var $newthumb = jQuery(this).find(".showoff-project-thumbnail img.new");
                        // Set animation delay
                        jQuery(this).find(".showoff-project-thumbnail img").css({
                            "animation-delay": ((i + 1) * 100) + "ms"
                        });
                        // Run css animations
                        $oldthumb.css({zIndex: 1}).addClass("animate-scaleDown");
                        $newthumb.css({zIndex: 0}).addClass("animate-rotateIn");
                    });
                break;
                
                case "flip3d" :
                    projects.li.each(function(i) {
                        var $oldthumb = jQuery(this).find(".showoff-project-thumbnail img.old");
                        var $newthumb = jQuery(this).find(".showoff-project-thumbnail img.new");
                        // Set animation delay
                        jQuery(this).find(".showoff-project-thumbnail img").css({
                            "animation-delay": ((i + 1) * 100) + "ms"
                        });
                        // Run css animations
                        
                        jQuery(this).addClass("animate-3d");
                        $oldthumb.css({zIndex: 1}).addClass("animate-rotateOutLeft");
                        $newthumb.css({zIndex: 0}).addClass("animate-rotateInRight");
                    });
                break;
                
                case "superscale" :
                    projects.li.each(function(i) {
                        var $oldthumb = jQuery(this).find(".showoff-project-thumbnail img.old");
                        var $newthumb = jQuery(this).find(".showoff-project-thumbnail img.new");
                        // Set animation delay
                        jQuery(this).find(".showoff-project-thumbnail img").css({
                            "animation-delay": ((i + 1) * 100) + "ms"
                        });
                        // Run css animations
                        
                        $oldthumb.css({zIndex: 1}).addClass("animate-scaleDown");
                        $newthumb.css({zIndex: 0}).addClass("animate-scaleIn");
                    });
                break;
                
                case "centerflip" :
                    projects.li.each(function(i) {
                        var $oldthumb = jQuery(this).find(".showoff-project-thumbnail img.old");
                        var $newthumb = jQuery(this).find(".showoff-project-thumbnail img.new");
                        // Set animation delay
                        jQuery(this).find(".showoff-project-thumbnail img").css({
                            "animation-delay": ((i + 1) * 100) + "ms"
                        });
                        // Run css animations
                        
                        jQuery(this).addClass("animate-3d");
                        $oldthumb.css({zIndex: 1}).addClass("animate-flipOut");
                        $newthumb.css({zIndex: 0}).addClass("animate-flipIn");
                    });
                break;
                
                case "random":
                    var animationArray = new Array(
                        "centerflip",
                        "superscale",
                        "flip3d",
                        "rotate_scale",
                        "fallrotate_fadein",
                        "falldown_scaleup"
                    );
                        
                    glob.options.animationtype = animationArray[Math.floor(Math.random() * animationArray.length)];
                    projects.swapAnimation();
                    glob.options.animationtype = "random";
                    return;
                break;
            }
            
            
            var animationDuration = parseFloat(projects.li.eq(0).find(".showoff-project-thumbnail img:first").css("animation-duration")) * 1000;

            // Animations complete
            setTimeout(function() {
                projects.li.each(function() {
                    jQuery(this).removeClass("animate-3d");
                    jQuery(this).find(".showoff-project-thumbnail img.old").remove();
                    jQuery(this).find(".showoff-project-thumbnail img.new").attr("class","");
                    
                    if (jQuery(this).find(".showoff-project-inner").length <= 0) {
                        jQuery(this).slideUp(250);
                    }
                });
           
                projects.categories.filter();
                
                projects.swapping = false;
                
                // Check _GET_PROJECT
                if (glob.options._get_project) {
                    setTimeout(function() {
                        // Timeout is required since empty projects could be closing at the bottom
                        jQuery(".showoff-project-id-" + glob.options._get_project).trigger("click");
                        // Stop if already opened once
                        glob.options._get_project = 0;
                    }, 300)
                }
                
            }, projects.li.length * 100 + animationDuration);
        },
                
        swap: function(data) {

            // Swap elements fn
            var swap = function() {
                
                projects.swapping = true;
                
                // Update pagination
                if (data.pages) {
                    jQuery(glob.instance).find(".showoff-pagination").empty();
                    jQuery(data.pages).children().appendTo(jQuery(glob.instance).find(".showoff-pagination"));
                }
                
                projects.li.each(function(i) {
                    
                    var $projectclass = jQuery(data.html).find("> li").eq(i).attr("class");
                    
                    var $oldinner = jQuery(this).find(".showoff-project-inner");
                    var $newinner = jQuery(data.html).find("> li").eq(i).find(".showoff-project-inner");
                    
                    var $newhover = jQuery(data.html).find("> li").eq(i).find(".showoff-project-thumbnail-hover");
                    var $oldhover = jQuery(this).find(".showoff-project-thumbnail-hover");
                    
                    var $oldthumb = jQuery(this).find(".showoff-project-thumbnail img:first");
                    var $newthumb = jQuery(data.html).find("> li").eq(i).find(".showoff-project-thumbnail img:last");
                        
                    if ($newinner.length > 0) {
                        jQuery(this).slideDown(250);
                    }
                    
                    jQuery(this).attr("class", $projectclass);
                    
                    if (helper.isModern() === false) {
                        $newthumb.fadeTo(0,0);
                    }
                    
                    $oldthumb.addClass("old");
                    $newthumb.addClass("new");
                    
                    if ($newthumb.length <= 0) {
                        // No new thumb. Remove on animation complete
                        $oldthumb.addClass("empty");
                    }

                    // Delete old hover thumb
                    $oldhover.remove();

                    // Delete old inner content
                    $oldinner.remove();

                    // Add new thumb-hover
                    jQuery($newhover).appendTo(jQuery(this).find(".showoff-project-thumbnail"));
                    
                    // Add new inner content
                    jQuery($newinner).appendTo(jQuery(this));
                    
                    // Add new thumb
                    jQuery($newthumb).appendTo(jQuery(this).find(".showoff-project-thumbnail"));
                    
                    // Check media query
                    helper.mediaQuery();

                    // Re-set dimensions
                    projects.dimensions(jQuery(this), true);
                });
                
                projects.swapAnimation();
                
            };

            // Check open
            if (projects.li.hasClass("active")) {
                projects.inner.hide(function() {
                    swap();
                });
            } else {
                swap();
            }
        },
        pagination: {
            active: "1",
            set: function(th) {
                var newpageid = jQuery(th).attr("id").replace("showoff-page-", "");
                if (projects.pagination.active === newpageid)
                    return;

                if (jQuery(glob.instance).find(".showoff-content > ul").length > 1)
                    return;

                jQuery(th).siblings().removeClass("active");
                jQuery(th).addClass("active");
                projects.pagination.active = newpageid;
                this.get();

            },
            get: function() {
                glob.page = projects.pagination.active;
                ajax.getProjects();
            }
        },
        categories: {
            active: "0",
            filter: function() {
                if (glob.options.catfilter === "allvisible") {
                    
                    if (helper.isModern() === false) {
                        jQuery(glob.instance).find(".showoff-project-thumbnail img").css({
                            position: "static"
                        });
                    }
                    
                    if (projects.categories.active === "0") {
                        projects.li.removeClass("inactive");
                    } else {
                        projects.li.filter(":visible").removeClass("inactive").each(function(){
                            var th = this;
                            var cats = jQuery(this).attr("class").split(" ")[1].replace("showoff-project-cat-","");
                            var inactive = 1;
                            
                            cats = cats.split("-");
                            
                            jQuery(cats).each(function(){
                                if (parseFloat(projects.categories.active) === parseFloat(this)) {
                                     inactive = 0;
                                } 
                            });
                            
                            if (inactive === 1) {
                                jQuery(th).addClass("inactive");
                            }
                        });
                    }
                }
            },
            set: function(th) {
                
                var newcatid;
                if (th.nodeName === "SELECT") {
                    newcatid = jQuery(th).attr("value").replace("showoff-cat-", "");
                } else {
                    newcatid = jQuery(th).attr("id").replace("showoff-cat-", "");
                }
                
                if (projects.categories.active === newcatid) return;
             
                projects.categories.active = newcatid;
                jQuery(glob.instance).find(".showoff-categories a").removeClass("active");
                jQuery(glob.instance).find(".showoff-categories a#showoff-cat-" + projects.categories.active).addClass("active");
                jQuery(glob.instance).find(".showoff-categories-mini").val("showoff-cat-"+newcatid);
                
                this.filter();
                this.get();
            },
            get: function() {

                var get = function() {
                    switch (glob.options.catfilter) {
                        case "allvisible":
                            if (projects.categories.active === "0") {
                                projects.li.removeClass("inactive");
                                return;
                            }
                            break;

                        case "standard" :
                            glob.page = 1;
                            projects.pagination.active = 1;
                            glob.cat = projects.categories.active;
                            ajax.getProjects();
                            break;
                    }
                };

                // Check Open
                if (jQuery(glob.instance).find(".showoff-content > ul > li").hasClass("active")) {
                    projects.inner.hide(function() {
                        get();
                    });
                } else {
                    get();
                }

            }
        }
    };
}

jQuery(window).load(function() {
    if (typeof showoff_instance !== "undefined") {
        var i = 0;
        while (showoff_instance[i]) {
            new showoff().init(showoff_instance[i]);
            i++;
        }
        delete showoff_instance;
    }
});