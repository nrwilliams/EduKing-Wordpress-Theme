<?php $options = showoff::get_options(); ?>

<!-- Admin Wrapper Start -->
<div class="admin_wrapper">

    <!-- Admin Section Start -->
    <div class="admin_section">

        <!-- Admin Section Header Start -->
        <div class="admin_section_header">
            <h2><?php _e("Showoff General Settings","showoff"); ?></h2>
            <p><?php _e("Adjust General Settings","showoff"); ?></p>
        </div><!--/admin_section_header -->
        <!-- Admin Section Header End -->


        <!-- Admin Section Body Start -->
        <div class="admin_section_body">
            <form action="?page=<?php echo $plugin_page; ?>&view=general" method="POST">
                
                <?php $fontsArray = showoff::get_fonts(); ?>
                
                <label>
                    <span><?php _e("Front Title","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="title" type="text" value="<?php echo $options->title; ?>" />
                    <p>(<?php _e("Enter front-end title or leave empty","showoff"); ?>)</p>
                </label>

                
                <label>
                    <span><?php _e("Buttons Font-Family","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff"); ?>)</span><br />
                    <select class="showoff-field-required"  name="buttonsfont">
                        <?php foreach ($fontsArray as $font) : ?>
                        <option <?php if ($options->buttonsfont == $font) echo 'selected="selected"'; ?>><?php echo $font; ?></option>
                        <?php endforeach;  ?>
                    </select>
                    <p>(<?php _e("Pick Navigation, Pagination and Read More Buttons) Font-Family","showoff"); ?>)</p>
                </label>
               
                <label>
                    <span><?php _e("Title Font-Family","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff"); ?>)</span><br />
                    <select class="showoff-field-required"  name="titlefont">
                        <?php foreach ($fontsArray as $font) : ?>
                        <option <?php if ($options->titlefont == $font) echo 'selected="selected"'; ?>><?php echo $font; ?></option>
                        <?php endforeach;  ?>
                    </select>
                    <p>(<?php _e("Pick Title Font-Family","showoff"); ?>)</p>
                </label>
               
                <label>
                    <span><?php _e("Project Description Title Font-Family","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff"); ?>)</span><br />
                    <select class="showoff-field-required"  name="projectitlefont">
                        <?php foreach ($fontsArray as $font) : ?>
                        <option <?php if ($options->projectitlefont == $font) echo 'selected="selected"'; ?>><?php echo $font; ?></option>
                        <?php endforeach;  ?>
                    </select>
                    <p>(<?php _e("Pick Project Description Title Font-Family","showoff"); ?>)</p>
                </label>
               
                <label>
                    <span><?php _e("Project Description Text Font-Family","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff"); ?>)</span><br />
                    <select class="showoff-field-required"  name="projecdescfont">
                        <?php foreach ($fontsArray as $font) : ?>
                        <option <?php if ($options->projecdescfont == $font) echo 'selected="selected"'; ?>><?php echo $font; ?></option>
                        <?php endforeach;  ?>
                    </select>
                    <p>(<?php _e("Pick Project Description Text Font-Family","showoff"); ?>)</p>
                </label>
               
                <label>
                    <span><?php _e("Thumbnail Title Font-Family","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff"); ?>)</span><br />
                    <select class="showoff-field-required"  name="projecthoverfont">
                        <?php foreach ($fontsArray as $font) : ?>
                        <option <?php if ($options->projecthoverfont == $font) echo 'selected="selected"'; ?>><?php echo $font; ?></option>
                        <?php endforeach;  ?>
                    </select>
                    <p>(<?php _e("Pick Thumbnail Title Font-Family","showoff"); ?>)</p>
                </label>
                
                <!-- Color Picker Start -->
                <label>
                    <span><?php _e("Plugin Title Text Color","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="titlecolor" type="text" class="showoff_color_picker" value="<?php echo $options->titlecolor; ?>" />
                    <p>(<?php _e("Pick Plugin Text Title Color","showoff"); ?>)</p>
                </label>
                <!-- Color Pocker End -->
                
                <!-- Color Picker Start -->
                <label>
                    <span><?php _e("Project Title Text Color","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="projecttitlecolor" type="text" class="showoff_color_picker" value="<?php echo $options->projecttitlecolor; ?>" />
                    <p>(<?php _e("Pick Project Title Text Color","showoff"); ?>)</p>
                </label>
                <!-- Color Pocker End -->
                
                
                <!-- Color Picker Start -->
                <label>
                    <span><?php _e("Project Inner Text Color","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="projectinnercolor" type="text" class="showoff_color_picker" value="<?php echo $options->projectinnercolor; ?>" />
                    <p>(<?php _e("Pick Project Inner Text Color","showoff"); ?>)</p>
                </label>
                <!-- Color Pocker End -->
                
                
                <!-- Color Picker Start -->
                <label>
                    <span><?php _e("Buttons Background Color","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="buttonbgcolor" type="text" class="showoff_color_picker" value="<?php echo $options->buttonbgcolor; ?>" />
                    <p>(<?php _e("Pick Navigation, Pagination and Read More Buttons Background Color","showoff"); ?>)</p>
                </label>
                <!-- Color Pocker End -->
                
                <!-- Color Picker Start -->
                <label>
                    <span><?php _e("Buttons Text Color","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="buttoncolor" type="text" class="showoff_color_picker" value="<?php echo $options->buttoncolor; ?>" />
                    <p>(<?php _e("Pick Navigation, Pagination and Read More Buttons Text Color","showoff"); ?>)</p>
                </label>
                <!-- Color Pocker End -->
                
                <!-- Color Picker Start -->
                <label>
                    <span><?php _e("Buttons Hover Background Color","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="buttonbgcolorhover" type="text" class="showoff_color_picker" value="<?php echo $options->buttonbgcolorhover; ?>" />
                    <p>(<?php _e("Pick Navigation, Pagination and Read More Buttons On-Hover Background Color","showoff"); ?>)</p>
                </label>
                <!-- Color Pocker End -->
                
                <!-- Color Picker Start -->
                <label>
                    <span><?php _e("Buttons Hover Text Color","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="buttoncolorhover" type="text" class="showoff_color_picker" value="<?php echo $options->buttoncolorhover; ?>" />
                    <p>(<?php _e("Pick Navigation, Pagination and Read More Buttons On-Hover Text Color","showoff"); ?>)</p>
                </label>
                <!-- Color Pocker End -->
                
                
                <!-- Color Picker Start -->
                <label>
                    <span><?php _e("Buttons Active Background Color","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="buttonbgcoloractive" type="text" class="showoff_color_picker" value="<?php echo $options->buttonbgcoloractive; ?>" />
                    <p>(<?php _e("Pick Navigation, Pagination and Read More Buttons Active Background Color","showoff"); ?>)</p>
                </label>
                <!-- Color Pocker End -->
                
                <!-- Color Picker Start -->
                <label>
                    <span><?php _e("Buttons Active Text Color","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="buttoncoloractive" type="text" class="showoff_color_picker" value="<?php echo $options->buttoncoloractive; ?>" />
                    <p>(<?php _e("Pick Navigation, Pagination and Read More Buttons Active Text Color","showoff"); ?>)</p>
                </label>
                <!-- Color Pocker End -->
                
                
                
                 <!-- Color Picker Start -->
                <label>
                    <span><?php _e("Navigation Control Color","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="navicolor" type="text" class="showoff_color_picker" value="<?php echo $options->navicolor; ?>" />
                    <p>(<?php _e("Pick Navigation Control Color (Dots, Arrows...)","showoff"); ?>))</p>
                </label>
                <!-- Color Pocker End -->
                
                
                 <!-- Color Picker Start -->
                <label>
                    <span><?php _e("Navigation Control Hover Color","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="navicolorhover" type="text" class="showoff_color_picker" value="<?php echo $options->navicolorhover; ?>" />
                    <p>(<?php _e("Pick Navigation Control On-Hover Color (Dots, Arrows...)","showoff"); ?>)</p>
                </label>
                <!-- Color Pocker End -->
                
                
                 <!-- Color Picker Start -->
                <label>
                    <span><?php _e("Navigation Control Active Color","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="navicoloractive" type="text" class="showoff_color_picker" value="<?php echo $options->navicoloractive; ?>" />
                    <p>(<?php _e("Pick Navigation Control Active Color (Dots, Arrows...)","showoff"); ?>)</p>
                </label>
                <!-- Color Pocker End -->
                
                
                
                
                <!-- Color Picker Start -->
                <label>
                    <span><?php _e("Project Thumbnail Hover Background Color","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="projectbgcolorhover" type="text" class="showoff_color_picker" value="<?php echo $options->projectbgcolorhover; ?>" />
                    <p>(<?php _e("Pick Project Thumbnail On-Hover Background Color","showoff"); ?>)</p>
                </label>
                <!-- Color Pocker End -->
                
                <!-- Color Picker Start -->
                <label>
                    <span><?php _e("Project Thumbnail Hover Text Color","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="projectcolorhover" type="text" class="showoff_color_picker" value="<?php echo $options->projectcolorhover; ?>" />
                    <p>(<?php _e("Pick Project Thumbnail Hover Text Color (Title and Eye Color)","showoff"); ?>)</p>
                </label>
                <!-- Color Pocker End -->
                
                
                <!-- Color Picker Start -->
                <label>
                    <span><?php _e("Project Inner Background Color","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="projectinnerbgcolor" type="text" class="showoff_color_picker" value="<?php echo $options->projectinnerbgcolor; ?>" />
                    <p>(<?php _e("Pick Project Inner Background Color","showoff"); ?>)</p>
                </label>
                <!-- Color Pocker End -->
                
                
                
                <label>
                    <span><?php _e("Project Hover Effect Style","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <select name="projecthoverstyle">
                        <option <?php if ($options->projecthoverstyle == "icon") echo 'selected="selected"'; ?> value="icon">Icon</option>
                        <option <?php if ($options->projecthoverstyle == "title") echo 'selected="selected"'; ?> value="title">Title</option>
                    </select>
                    <p>(<?php _e("Pick Project On-Hover Effect Style - Project Title or Eye Icon","showoff"); ?>)</p>
                </label>
                
                
                
                 <label>
                    <span><?php _e("Thumbnail Hover Effect Type","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <select name="projecthovertype">
                        <option <?php if ($options->projecthovertype == "modern") echo 'selected="selected"'; ?> value="modern">3D (Modern browers)</option>
                        <option <?php if ($options->projecthovertype == "legacy") echo 'selected="selected"'; ?> value="legacy">2D (Opacity Hover)</option>
                    </select>
                    <p>(<?php _e("Pick Thumbnail Hover Effect Type. If browser does not support CSS3, 2D effect will be used","showoff"); ?>)</p>
                </label>
                
                <label>
                    <span><?php _e("2D Thumbnail Hover Opacity","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="projecthoveropacity" type="text" value="<?php echo $options->projecthoveropacity; ?>" />
                    <p>(<?php _e("2D Hover Thumbnail Opacity value between 0 and 1","showoff"); ?>)</p>
                </label>
                
                
                
                <label>
                    <span><?php _e("Projects Columns","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff"); ?>)</span><br />
                    <input class="showoff-field-required"  name="cols" type="text" value="<?php echo $options->cols; ?>" />
                    <p>(<?php _e("Enter number of columns to display","showoff"); ?>)</p>
                </label>
                
                <label>
                    <span><?php _e("Projects Per Page","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff"); ?>)</span><br />
                    <input class="showoff-field-required"  name="perpage" type="text" value="<?php echo $options->perpage; ?>" />
                    <p>(<?php _e("Number of Visible Project Per Page","showoff"); ?>)</p>
                </label>

                <label>
                    <span><?php _e("Projects Spacing","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff"); ?>)</span><br />
                    <input class="showoff-field-required" name="spacing" type="text" value="<?php echo $options->spacing; ?>" />
                    <p>(<?php _e("Space between projects in percents","showoff"); ?>)</p>
                </label>

                <label>
                    <span><?php _e("Thumbnail Aspect Ratio","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff"); ?>)</span><br />
                    <input class="showoff-field-required" name="aspect" type="text" value="<?php echo $options->aspect; ?>" />
                    <p>(<?php _e("Thumbnail Aspect Ratio (X by 1)","showoff"); ?>)</p>
                </label>
                
                <label>
                    <span><?php _e("Project Focus Offset","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff"); ?>)</span><br />
                    <input name="focusoffset" type="text" value="<?php echo $options->focusoffset; ?>" />
                    <p>(<?php _e("Set Project Focus Offset (in pixels)","showoff"); ?>)</p>
                </label>
                

                <label>
                    <span><?php _e("Swap Animation","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff"); ?>)</span><br />
                    <select class="showoff-field-required"  name="animationtype">
                        <option value="falldown_scaleup" <?php if ($options->animationtype === "falldown_scaleup") echo 'selected="selected"'; ?>><?php _e("FallDown / ScaleUp","showoff"); ?></option>
                        <option value="fallrotate_fadein" <?php if ($options->animationtype === "fallrotate_fadein") echo 'selected="selected"'; ?>><?php _e("FallRotate / FadeIn","showoff"); ?></option>
                        <option value="rotate_scale" <?php if ($options->animationtype === "rotate_scale") echo 'selected="selected"'; ?>><?php _e("Rotate Scale","showoff"); ?></option>
                        <option value="flip3d" <?php if ($options->animationtype === "flip3d") echo 'selected="selected"'; ?>><?php _e("3D Flip","showoff"); ?></option>
                        <option value="superscale" <?php if ($options->animationtype === "superscale") echo 'selected="selected"'; ?>><?php _e("Super Scale","showoff"); ?></option>
                        <option value="centerflip" <?php if ($options->animationtype === "centerflip") echo 'selected="selected"'; ?>><?php _e("Center Flip","showoff"); ?></option>
                        <option value="random" <?php if ($options->animationtype === "random") echo 'selected="selected"'; ?>><?php _e("Random","showoff"); ?></option>
                    </select>
                    <p>(<?php _e("Projects Swap Animation Type (Modern Browsers Only!)","showoff"); ?>)</p>
                </label>
                
                <label>
                    <span><?php _e("Lightbox","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff"); ?>)</span><br />
                    <select class="showoff-field-required"  name="lightbox">
                        <option value="0" <?php if ($options->lightbox == "0") echo 'selected="selected"'; ?>><?php _e("Disable","showoff"); ?></option>
                        <option value="1" <?php if ($options->lightbox == "1") echo 'selected="selected"'; ?>><?php _e("Enable","showoff"); ?></option>
                    </select>
                    <p>(<?php _e("Enable/Disable Lightbox","showoff"); ?>)</p>
                </label>
                
                <label>
                    <span><?php _e("Lightbox Share Buttons","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff"); ?>)</span><br />
                    <select class="showoff-field-required"  name="sharebuttons">
                        <option value="0" <?php if ($options->sharebuttons == "0") echo 'selected="selected"'; ?>><?php _e("Hide","showoff"); ?></option>
                        <option value="1" <?php if ($options->sharebuttons == "1") echo 'selected="selected"'; ?>><?php _e("Show","showoff"); ?></option>
                    </select>
                    <p>(<?php _e("Show/Hide Lightbox Share Buttons","showoff"); ?>)</p>
                </label>
                
                <label>
                    <span><?php _e("Category Filter Type","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff"); ?>)</span><br />
                    <select class="showoff-field-required" name="catfilter">
                        <option value="standard" <?php if ($options->catfilter === "standard") echo 'selected="selected"'; ?>><?php _e("Standard","showoff"); ?></option>
                        <option value="allvisible" <?php if ($options->catfilter === "allvisible") echo 'selected="selected"'; ?>><?php _e("All Visible","showoff"); ?></option>
                    </select>
                    <p>(<?php _e("Category Filter Type","showoff"); ?>)</p>
                </label>
                
                <label>
                    <span><?php _e("Default Categories","showoff"); ?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff"); ?>)</span><br />
                    <select class="showoff-field-required" name="cat[]" multiple>
                        <?php $categories = showoff::get_categories(); ?>
                        <?php $active_cats = explode(",",$options->cat); ?>
                        <?php foreach ($categories as $category) : ?>
                        <option <?php if (in_array($category->id, $active_cats)) echo "selected"; ?> value="<?php echo $category->id ?>"><?php echo $category->title ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p>(<?php _e("Project Categories to display by default)","showoff"); ?>)</p>
                </label>
                
                <!-- Button Start -->
                <button><?php _e("Save Settings","showoff"); ?></button>
                <input type="hidden" name="task" value="save" />
            </form>
            <button class="showoff-reset-defaults"><?php _e("Reset Defaults","showoff"); ?></button>
            <button onclick="window.location.href = '?page=<?php echo $plugin_page; ?>';"><?php _e("Cancel","showoff"); ?></button>
            <!-- Button End -->

        </div><!--/admin_section_body-->
        <!-- Admin Section Body End -->

    </div><!--/admin_section -->
    <!-- Admin Section End -->

</div><!--/admin_wrapper-->
<!-- Admin Wrapper End -->