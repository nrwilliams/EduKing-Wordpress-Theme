<div class="admin_wrapper">
    <div class="admin_section">
        <div class="admin_section_header">
            <h2><?php _e("Add/Edit Category","showoff");?></h2>
            <p><?php _e("Create new or edit existing category","showoff");?></p>
        </div>

        <div class="admin_section_body">
            <form action="?page=<?php echo $plugin_page; ?>&view=list" method="POST">
                <?php
                /*
                 *  $category - Category Object Array ($_REQUEST["catid"])
                 *  if $category - update table;
                 *  else - create new category;
                 * 
                 */
                $category = showoff::get_category();
                ?>

                <label>
                    <span><?php _e("Category Title","showoff");?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff");?>)</span><br />
                    <input class="showoff-field-required" type="text" name="title" value="<?php echo $category ? $category->title : "" ?>"/>
                    <p>(<?php _e("Name of the category","showoff");?>)</p>
                </label>

                <input type="hidden" name="task" value="create" />
                <?php if ($category) : ?><input type="hidden" name="update" value="<?php echo $category->id; ?>" /><?php endif; ?>
                <?php if ($category) : ?><button><?php _e("Update Category","showoff");?></button><?php else: ?><button><?php _e("Save Category","showoff");?></button><?php endif; ?>

            </form>
            <button onclick="window.location.href = '?page=<?php echo $plugin_page; ?>&view=list';"><?php _e("Cancel","showoff");?></button>
        </div>
    </div>
</div>
