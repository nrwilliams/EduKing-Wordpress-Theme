<!-- Admin Wrapper Start -->
<div class="admin_wrapper">

    <!-- Admin Section Start -->
    <div class="admin_section">

        <!-- Admin Section Header Start -->
        <div class="admin_section_header">
            <h2><?php _e("Create / Edit Project","showoff");?></h2>
            <p><?php _e("Create / Edit Project","showoff");?></p>
        </div><!--/admin_section_header -->
        <!-- Admin Section Header End -->

        <!-- Admin Section Body Start -->
        <div class="admin_section_body">
            <form action="?page=<?php echo $plugin_page; ?>&view=list" method="POST">
                <?php
                /*
                 *  $project - Project Object ($_REQUEST["id"])
                 *  if $project - update table;
                 *  else - create new project;
                 * 
                 */
                $project = showoff::get_project();
                ?>
                <!-- Text Field Start -->
                <label>
                    <span><?php _e("Project Title","showoff");?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff");?>)</span><br />
                    <input class="showoff-field-required" name="title" type="text" value="<?php echo $project ? $project->title : ""; ?>" />
                    <p>(<?php _e("Enter Project Title","showoff");?>)</p>
                </label>
                <!-- Text Field End -->

                <!-- Select Field Start -->
                <label>
                    <span><?php _e("Project Category","showoff");?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff");?>)</span><br />
                    <select class="showoff-field-required" name="catid[]" multiple>
                        <?php $categories = showoff::get_categories(); ?>
                        <?php foreach ($categories as $category): ?>
                            <?php $projectcatid = explode(",",$project->catid); ?>
                            <option <?php echo $project && (in_array($category->id, $projectcatid)) ? "selected" : ""; ?> value="<?php echo $category->id; ?>"><?php echo $category->title; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p>(<?php _e("Select Project Category. Hold Shift Key to select multiple categories.","showoff");?>)</p>
                </label>
                <!-- Select Field End -->

                <!-- Text Field Start -->
                <label>
                    <span><?php _e("Project Thumbnail","showoff");?></span>
                    <span class="caption_note">(<?php _e("Required!","showoff");?>)</span><br />
                    <input class="showoff-field-required" name="thumbnail" type="text" value="<?php echo $project ? $project->thumbnail : ""; ?>" />
                    <p>(<?php _e("Pick Project Thumbnail","showoff");?>)</p>
                </label>
                <!-- Text Field End -->

                <!-- Text Field Start -->
                <?php
                if ($project) :
                    $images = explode("||", $project->image);
                    foreach ($images as $image):
                        if ($image):
                            ?>
                            <label>
                                <span><?php _e("Project Image","showoff");?></span>
                                <span class="caption_note">(<?php _e("Optional.","showoff");?>)</span><br />
                                <input name="image[]" type="text" value="<?php echo $image; ?>" />
                                <p>(<?php _e("Project Image, Screenshot etc...","showoff");?>)</p>
                            </label>
                            <?php
                        endif;
                    endforeach;
                endif;
                ?>
                
                <label>
                    <span><?php _e("Project Image","showoff");?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff");?>)</span><br />
                    <input name="image[]" type="text" value="" />
                    <p>(<?php _e("Project Image, Screenshot etc...","showoff");?>)</p>
                </label>
                <!-- Text Field End -->

                <button class="add_more_images"><?php _e("Add More Images","showoff");?></button>

                <!-- Text Area Start -->
                <label>
                    <span><?php _e("Project Description","showoff");?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff");?>)</span><br />
                    <textarea name="content" cols="" rows=""><?php echo $project ? $project->content : ""; ?></textarea>
                    <p>(<?php _e("Project Description (Text or HTML)","showoff");?>)</p>
                </label>                
                <!-- Text Area End -->

                <!-- Text Field Start -->
                <label>
                    <span><?php _e("Read More Link","showoff");?></span>
                    <span class="caption_note">(<?php _e("Optional.","showoff");?>)</span><br />
                    <input name="readmore" type="text" value="<?php echo $project ? $project->readmore : ""; ?>" />
                    <p>(<?php _e("Link for further reading","showoff");?>)</p>
                </label>
                <!-- Text Field End -->             

                <?php if ($project) : ?>
                <input type="hidden" name="update" value="<?php echo $project->id; ?>" />
                <?php endif; ?>
                <input type="hidden" name="task" value="create" />
                <button><?php _e("Save Project","showoff");?></button>
            </form>
            <button onclick="window.location.href = '?page=<?php echo $plugin_page; ?>&view=list';"><?php _e("Cancel","showoff");?></button>
        </div><!--/admin_section_body-->
        <!-- Admin Section Body End -->

    </div><!--/admin_section -->
    <!-- Admin Section End -->

</div><!--/admin_wrapper-->
<!-- Admin Wrapper End -->