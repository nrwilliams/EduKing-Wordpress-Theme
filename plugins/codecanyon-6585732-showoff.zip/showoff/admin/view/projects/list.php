<div class="admin_wrapper">
    <div class="admin_section">
        <div class="admin_section_header">
            <h2><?php _e("Projects List","showoff");?></h2>
            <p><?php _e("Create / Edit Projects","showoff");?></p>
        </div>
        <div class="admin_section_body fullwidth">
            <button onclick="window.location.href = '?page=<?php echo $plugin_page; ?>&view=addedit';"><?php _e("Create New Project","showoff"); ?></button>
            <form method="POST">
                <button class="projects_reorder"><?php _e("Update Projects Order","showoff");?></button>
            </form>
            <ul class="list no-touch">
                <?php $projects = showoff::get_projects(); ?>
                <?php foreach ($projects as $project): ?>
                <li id="project-<?php echo $project->id; ?>">
                    <p><?php echo $project->title;?><span>(ID#<?php echo $project->id;?> <?php _e("Order","showoff"); ?>)</span></p>
                    <button onclick="window.location.href = '?page=<?php echo $plugin_page; ?>&view=list&task=delete&id=<?php echo $project->id; ?>';"><?php _e("Delete","showoff");?></button>
                    <button onclick="window.location.href = '?page=<?php echo $plugin_page; ?>&view=addedit&id=<?php echo $project->id;?>';"><?php _e("Edit","showoff");?></button>
                    <input autocomplete="off" type="text" name="order" value="<?php echo $project->ordering; ?>" />
                </li>
                <?php endforeach; ?>
            </ul>
            
            <ul class="pagination">
                <?php echo showoff::get_projects_pagination(); ?>
            </ul>
        </div>
    </div>
</div>
