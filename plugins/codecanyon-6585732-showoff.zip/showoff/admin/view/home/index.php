<div class="admin_wrapper">
    <div class="showoff_logo"></div>
    <p class="showoff_version">Version <span>1.06</span> / DB <span><?php echo get_option("showoff_db_version"); ?></span></p>
</div>