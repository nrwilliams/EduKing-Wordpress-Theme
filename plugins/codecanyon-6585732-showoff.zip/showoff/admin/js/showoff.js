function showoff() {
    
    "use strict";
    
    var glob = {
        ajax: false
    };
    
    this.init = function(){
        media.init();
        general.init();
        addEditProject.init();
        listProjects.init();
        listCategories.init();
        fieldCheck.init();
    };
    
    var general = {
        init: function(){
            this.bindControls();
        },
        
        set_option: function(name, val){
            name = name.replace("showoff-","");
            jQuery('.admin_wrapper [name='+name+']').val(val);
        },        
         
        bindControls: function() {
    
            jQuery(".showoff-reset-defaults").on("click", function(){
                
                jQuery('.showoff-field-required').css({
                        borderColor: "#ECECEC",
                        boxShadow: "none"
                });
                
                general.set_option("showoff-cols", 4);
                general.set_option("showoff-perpage", 8);
                general.set_option("showoff-spacing", 1);
                general.set_option("showoff-aspect", 1);
                general.set_option("showoff-animationtype", "random");
                general.set_option("showoff-catfilter", "standard");
                general.set_option("showoff-cat", "0");
                general.set_option("showoff-title", "Our Work");

                general.set_option("showoff-buttonsfont", "Roboto Condensed");
                general.set_option("showoff-titlefont", "Roboto Condensed");
                general.set_option("showoff-projectitlefont", "Roboto Condensed");
                general.set_option("showoff-projecdescfont", "Roboto Slab");
                general.set_option("showoff-projecthoverfont", "Roboto Condensed");

                general.set_option("showoff-titlecolor", "109,107,95");
                general.set_option("showoff-projecttitlecolor", "54,54,54");
                general.set_option("showoff-projectinnercolor", "101,101,101");

                general.set_option("showoff-buttonbgcolor", "255,85,86");
                general.set_option("showoff-buttoncolor", "255,255,255");
                general.set_option("showoff-buttonbgcolorhover", "252,183,85");
                general.set_option("showoff-buttoncolorhover", "255,255,255");
                general.set_option("showoff-buttonbgcoloractive", "188,188,188");
                general.set_option("showoff-buttoncoloractive", "255,255,255");
                general.set_option("showoff-projectbgcolorhover", "252,183,85");

                general.set_option("showoff-projecthoverstyle", "title");
                general.set_option("showoff-projecthovertype", "modern");
                general.set_option("showoff-projecthoveropacity", "1");
                general.set_option("showoff-projectcolorhover", "255,255,255");
                general.set_option("showoff-projectinnerbgcolor", "236,236,236");
                general.set_option("showoff-navicolor", "205,205,205");
                general.set_option("showoff-navicolorhover", "255,85,86");
                general.set_option("showoff-navicoloractive", "255,85,86");

                jQuery('.showoff_color_picker').each(function() {
                    jQuery(this).css({
                        backgroundColor: "rgb(" + jQuery(this).val() + ")"
                    });
                });
            });
            
            jQuery('.showoff_color_picker').each(function() {
                var th = this;
                
                var rgb = jQuery(th).val().split(",");
                
                var color = {
                    r: rgb[0],
                    g: rgb[1],
                    b: rgb[2]
                };
                
                jQuery(th).css({
                    backgroundColor: "rgb("+jQuery(th).val()+")"
                });
                
                jQuery(th).ColorPicker({
                    color: color,
                    onShow: function(colpkr) {
                        jQuery(colpkr).fadeIn(250);
                        return false;
                    },
                    onHide: function(colpkr) {
                        jQuery(colpkr).fadeOut(250);
                        return false;
                    },
                    onChange: function(hsb, hex, rgb) {
                        jQuery(th).val(rgb.r + "," + rgb.g + "," + rgb.b);
                        
                        jQuery(th).css({
                            backgroundColor: "rgb(" + jQuery(th).val() + ")"
                        });
                    }
                });
            });
        }
    };
    
    var listCategories = {
        init: function(){
            this.bindControls();
        },
        
        bindControls: function(){
            
            jQuery("button.categories_reorder").on("click", function(event){
                var th = this;
                
                jQuery(th).siblings().remove();
                
                jQuery(".list").children().each(function(i) {
                    var id = jQuery(this).attr("id").replace("category-", "");
                    var num = jQuery(this).find("input[type=text]").val();
                    jQuery(th).after('<input type="hidden" name="order[]" value="' + id + ":" + num + '" />');
                });
                
                jQuery(th).after('<input type="hidden" name="task" value="updateOrder" />');
            });
        }
    };
    
    var listProjects = {
        init: function(){
            this.bindControls();
        },
        
        bindControls: function(){
            
            jQuery("button.projects_reorder").on("click", function(event){
                var th = this;
                
                jQuery(th).siblings().remove();
                
                jQuery(".list").children().each(function(i) {
                    var id = jQuery(this).attr("id").replace("project-", "");
                    var num = jQuery(this).find("input[type=text]").val();
                    jQuery(th).after('<input type="hidden" name="order[]" value="' + id + ":" + num + '" />');
                });
                
                jQuery(th).after('<input type="hidden" name="task" value="updateOrder" />');
            });
        }
    };

    var media = {
        element: false,
        frame: "",
        init: function() {
            media.frame = wp.media({
                button: {
                    text: "Pick Image"
                },
                library: {
                    type: 'image' 
                },
                frame: 'select',
                title: "Choose Image",
                multiple: false
            });
        }
    };
        
    
    var addEditProject = {
        init: function(){
            this.bindControls();
        },
        bindControls: function(){
            
            jQuery(document).on("click",'input[name="thumbnail"], input[name="image[]"]', function() {
                media.element = this;
                media.frame.open();
            });
            
            media.frame.on('select', function() {
                var attachment = media.frame.state().get('selection').first().toJSON();
                if (!media.element) return;
                jQuery(media.element).val(attachment.url);
            });
    
            jQuery(".add_more_images").on("click", function(event){
                event.preventDefault();
                
                var html = "";
                
                html += '<label>';
                    html += '<span>Project Image</span>';
                    html += '<span class="caption_note">(Optional!)</span><br />';
                    html += '<input name="image[]" type="text" />';
                    html += '<p>(Project Image, Screenshot etc...)</p>';
                html += '</label>';
                
                jQuery(html).fadeTo(250,1).insertBefore(this);
                
            });
        }
    };
    
    var fieldCheck = {
        init: function(){
            jQuery("form").on("submit", function(){
                var valid = true;
                
                jQuery(".showoff-field-required").each(function() {
                    jQuery(this).css({
                        borderColor: "#ECECEC",
                        boxShadow: "none"
                    });
                    
                    if (!jQuery(this).val()) {
                        jQuery(this).css({
                            borderColor: "#ff5555",
                            boxShadow: "0 0 4px #ff5555"
                        });
                        valid = false;
                    }
                });
                
                return valid;
            });
        }
    }
};

jQuery(document).ready(function(){
    new showoff().init();
});