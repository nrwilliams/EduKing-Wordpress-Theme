<?php
class Showoff {
    
    private static $loaded = false;
    private static $options = false;
    private static $googleFonts = array();
    private static $loadFonts = array();
    
    
    public static function REQUEST($var, $type = "REQUEST", $default = false) {
        switch (strtolower($type)):
            case "get" :
                return isset($_GET["{$var}"]) ? stripslashes_deep($_GET["{$var}"]) : $default;
            break;
            case "post":
                return isset($_POST["{$var}"]) ? stripslashes_deep($_POST["{$var}"]) : $default;
            break;
            case "request":
            default: return isset($_REQUEST["{$var}"]) ? stripslashes_deep($_REQUEST["{$var}"]) : $default;
        endswitch;
    }
    
    public static function load_scripts() {
        
        if (self::$loaded === true) return;
        self::$loaded = true;
        
        $options = showoff::get_options();
        
        $googleFont = $options->buttonsfont;
        if (!in_array($googleFont, self::$loadFonts)) :
            self::$loadFonts[] = $googleFont;
        endif;
        
        $googleFont = $options->titlefont;
        if (!in_array($googleFont, self::$loadFonts)) :
            self::$loadFonts[] = $googleFont;
        endif;
        
        $googleFont = $options->projectitlefont;
        if (!in_array($googleFont, self::$loadFonts)) :
            self::$loadFonts[] = $googleFont;
        endif;
        
        $googleFont = $options->projecdescfont;
        if (!in_array($googleFont, self::$loadFonts)) :
            self::$loadFonts[] = $googleFont;
        endif;
        
        $googleFont = $options->projecthoverfont;
        if (!in_array($googleFont, self::$loadFonts)) :
            self::$loadFonts[] = $googleFont;
        endif;

        $fonts = urlencode(implode("|", self::$loadFonts));
        
        wp_enqueue_style("showoff-css-fa", "//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css");
        wp_enqueue_style("showoff-style", plugins_url("site/css/style.css", SHOWOFF_FILE));
        wp_enqueue_style("showoff-fonts", "//fonts.googleapis.com/css?family=$fonts");
        
        wp_enqueue_script("showoff-js-modernizr", plugins_url("site/js/modernizr.js", SHOWOFF_FILE));
        wp_enqueue_script("showoff-js-imagesloaded", plugins_url("site/js/imagesloaded.js", SHOWOFF_FILE), array("jquery"));
        wp_enqueue_script("showoff-js-easing", plugins_url("site/js/jquery.easing.js", SHOWOFF_FILE), array("jquery"));
        wp_enqueue_script("showoff-js", plugins_url("site/js/showoff.js", SHOWOFF_FILE), array("jquery"));
    }
    
    private static function rgb2hex($rgb, $opacity = false) {

        if (!$rgb) return "000000";
        $rgb  = explode(",",$rgb);
        
        $hex  = "";
        
        if ($opacity !== false) {
            $x =  floor($opacity * 255);
            $hex .= str_pad(dechex($x), 2, "0", STR_PAD_LEFT);
        }    
        
        $hex .= str_pad(dechex($rgb[0]), 2, "0", STR_PAD_LEFT);
        $hex .= str_pad(dechex($rgb[1]), 2, "0", STR_PAD_LEFT);
        $hex .= str_pad(dechex($rgb[2]), 2, "0", STR_PAD_LEFT);

        return $hex; 
    }
    
    public static function custom_css_style() {
        $options = showoff::get_options();
        ?>
        <style>
            
            #<?php echo $options->unique; ?> .showoff-top-title {font-family: <?php echo $options->titlefont; ?>}
            #<?php echo $options->unique; ?> .showoff-pagination a {font-family: <?php echo $options->buttonsfont; ?>}
            #<?php echo $options->unique; ?> .showoff-categories a {font-family: <?php echo $options->buttonsfont; ?>}

            #<?php echo $options->unique; ?> .showoff-project-inner-readmore {font-family: <?php echo $options->buttonsfont; ?>}
            #<?php echo $options->unique; ?> .showoff-project-inner h4 {font-family: <?php echo $options->projectitlefont; ?>}
            #<?php echo $options->unique; ?> .showoff-project-inner .showoff-project-inner-content {font-family: <?php echo $options->projecdescfont; ?>}

            #<?php echo $options->unique; ?> .showoff-project-inner-readmore {background: rgb(<?php echo $options->buttonbgcolor; ?>)}
            #<?php echo $options->unique; ?> .showoff-project-inner-readmore {color: rgb(<?php echo $options->buttoncolor; ?>)}

            #<?php echo $options->unique; ?> .showoff-project-inner-readmore:hover {background: rgb(<?php echo $options->buttonbgcolorhover; ?>)}
            #<?php echo $options->unique; ?> .showoff-project-inner-readmore:hover {color: rgb(<?php echo $options->buttoncolorhover; ?>)}

            #<?php echo $options->unique; ?> .showoff-categories a {background: rgb(<?php echo $options->buttonbgcolor; ?>)}
            #<?php echo $options->unique; ?> .showoff-categories a {color: rgb(<?php echo $options->buttoncolor; ?>)}

            #<?php echo $options->unique; ?> .showoff-categories a:hover {background: rgb(<?php echo $options->buttonbgcolorhover; ?>)}
            #<?php echo $options->unique; ?> .showoff-categories a:hover {color: rgb(<?php echo $options->buttoncolorhover; ?>)}

            #<?php echo $options->unique; ?> .showoff-categories a.active {background: rgb(<?php echo $options->buttonbgcoloractive; ?>)}
            #<?php echo $options->unique; ?> .showoff-categories a.active {color: rgb(<?php echo $options->buttoncoloractive; ?>)}

            #<?php echo $options->unique; ?> .showoff-pagination a{background: rgb(<?php echo $options->buttonbgcolor; ?>)}
            #<?php echo $options->unique; ?> .showoff-pagination a {color: rgb(<?php echo $options->buttoncolor; ?>)}

            #<?php echo $options->unique; ?> .showoff-pagination a:hover {background: rgb(<?php echo $options->buttonbgcolorhover; ?>)}
            #<?php echo $options->unique; ?> .showoff-pagination a:hover {color: rgb(<?php echo $options->buttoncolorhover; ?>)}

            #<?php echo $options->unique; ?> .showoff-pagination a.active {background: rgb(<?php echo $options->buttonbgcoloractive; ?>)}
            #<?php echo $options->unique; ?> .showoff-pagination a.active {color: rgb(<?php echo $options->buttoncoloractive; ?>)}

            #<?php echo $options->unique; ?> .showoff-project-thumbnail-hover {background: rgb(<?php echo $options->projectbgcolorhover; ?>)}
            #<?php echo $options->unique; ?> .showoff-project-thumbnail-hover i {color: rgb(<?php echo $options->projectcolorhover; ?>)}
            #<?php echo $options->unique; ?> .showoff-project-thumbnail-hover p {color: rgb(<?php echo $options->projectcolorhover; ?>)}
            #<?php echo $options->unique; ?> .showoff-project-thumbnail-hover p {font-family: <?php echo $options->projecthoverfont; ?>}

            #<?php echo $options->unique; ?> .showoff-project-inner-wrapper {color: rgb(<?php echo $options->projectinnerbgcolor; ?>)}

            #<?php echo $options->unique; ?> .showoff-project-inner-pagination-page {color: rgb(<?php echo $options->navicolor; ?>)}
            #<?php echo $options->unique; ?> .showoff-project-inner-pagination-page:hover {color: rgb(<?php echo $options->navicolorhover; ?>)}
            #<?php echo $options->unique; ?> .showoff-project-inner-pagination-page.active {color: rgb(<?php echo $options->navicoloractive; ?>)}

            #<?php echo $options->unique; ?> .showoff-project-inner-close {color: rgb(<?php echo $options->navicolor; ?>)}
            #<?php echo $options->unique; ?> .showoff-project-inner-close:hover {color: rgb(<?php echo $options->navicolorhover; ?>)}

            #<?php echo $options->unique; ?> .showoff-lightbox-close {color: rgb(<?php echo $options->navicolor; ?>)}
            #<?php echo $options->unique; ?> .showoff-lightbox-close:hover {color: rgb(<?php echo $options->navicolorhover; ?>)}

            #<?php echo $options->unique; ?> .showoff-lightbox-navigation a i {color: rgb(<?php echo $options->navicolor; ?>)}
            #<?php echo $options->unique; ?> .showoff-lightbox-navigation a i:hover {color: rgb(<?php echo $options->navicolorhover; ?>)}

            #<?php echo $options->unique; ?> .showoff-top-title {color: rgb(<?php echo $options->titlecolor; ?>)}
            #<?php echo $options->unique; ?> .showoff-project-inner h4 {color: rgb(<?php echo $options->projecttitlecolor; ?>)}
            #<?php echo $options->unique; ?> .showoff-project-inner .showoff-project-inner-content {color: rgb(<?php echo $options->projectinnercolor; ?>)}

            #<?php echo $options->unique; ?>.legacy .showoff-content li.active .showoff-project-thumbnail-hover,
            #<?php echo $options->unique; ?>.legacy .showoff-project-thumbnail:hover .showoff-project-thumbnail-hover {
                
                background:none;
                -ms-filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#<?php echo self::rgb2hex($options->projectbgcolorhover, $options->projecthoveropacity); ?>, endColorstr=#<?php echo self::rgb2hex($options->projectbgcolorhover, $options->projecthoveropacity); ?>);
                filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#<?php echo self::rgb2hex($options->projectbgcolorhover, $options->projecthoveropacity); ?>, endColorstr=#<?php echo self::rgb2hex($options->projectbgcolorhover, $options->projecthoveropacity); ?>);
                zoom: 1;
                
                background: rgba(<?php echo $options->projectbgcolorhover; ?>, <?php echo $options->projecthoveropacity; ?>);
                opacity:1;
            }
            
            #<?php echo $options->unique; ?> .showoff-project-inner-media img {cursor:<?php echo $options->lightbox == "0" ? 'default' : 'pointer' ?>;}
            
        </style>
        <?php
    }
    
    public static function get_fonts() {
        if (empty(self::$googleFonts)) {
            $file = file_get_contents(plugin_dir_path( SHOWOFF_FILE ) . 'admin/css/googlefonts/googlefonts_json');
            $json = json_decode($file);
            $fonts = $json->items;
            self::$googleFonts = array();
            foreach ($fonts as $font) {
                $key = str_replace(" ", " ", $font->family);
                self::$googleFonts[$key] = $font->family;
            }
        }

        return self::$googleFonts;
    }
    
    private static function clean_cat($cat = 0, $return_array = 0) {
        if (is_string($cat)) {
            $cat = explode(",", $cat);
        }
        foreach ($cat as $k => $v) {
            $cat[$k] = (int) $v;
        }
        
        if ($return_array) {
            return $cat;
        } else {
            $cat = implode(",", $cat);
            return $cat;
        } 
        
    }
    
    public static function unique() {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $string = '';
        for ($i = 0; $i < 10; $i++) {
            $pos = rand(0, strlen($chars) - 1);
            $string .= $chars{$pos};
        }
        return "showoff-" . $string;
    }
    
    public static function register_js_instance() {
        
        $options = self::$options;
        
        $showoffOptions = array();
        foreach ($options as $key => $value) :
            $showoffOptions[] = '"' . $key . '"' . ':' . '"' . $value . '"';
        endforeach;
        $showoffOptions = "{" . implode(",", $showoffOptions) . "}";
        ?>

        <script type='text/javascript'>
            if (typeof showoff_instance === "undefined") {
                var showoff_instance = [];
            }
            
            showoff_instance.push(<?php echo $showoffOptions; ?>);
        </script>
        
        <?php
    }
    
    public static function set_options($options) {
        self::$options = $options;
    }
    
    public static function clear_options() {
        self::$options = false;
    }
    
    public static function get_option($opt = "", $default = false) {
        return get_option("showoff-".$opt, $default);
    }
    
    public static function get_options(){
        
        if (self::$options !== false) return self::$options;
        
        $options = new stdClass();
        
        $options->cols           = get_option("showoff-cols", 4);
        $options->perpage        = get_option("showoff-perpage", 8);
        $options->spacing        = get_option("showoff-spacing", 1);
        $options->aspect         = get_option("showoff-aspect", 1);
        $options->focusoffset    = get_option("showoff-focusoffset", 0);
        
        $options->animationtype  = get_option("showoff-animationtype", "random");
        $options->catfilter      = get_option("showoff-catfilter", "standard");
        $options->cat            = get_option("showoff-cat", "0");
        $options->title          = get_option("showoff-title", "Our Work");
        
        $options->lightbox       = get_option("showoff-lightbox", "1");
        $options->sharebuttons   = get_option("showoff-sharebuttons", "1");
        
        $options->buttonsfont      = get_option("showoff-buttonsfont", "Roboto Condensed");
        $options->titlefont        = get_option("showoff-titlefont", "Roboto Condensed");
        $options->projectitlefont  = get_option("showoff-projectitlefont", "Roboto Condensed");
        $options->projecdescfont   = get_option("showoff-projecdescfont", "Roboto Slab");
        $options->projecthoverfont = get_option("showoff-projecthoverfont", "Roboto Condensed");
        
        $options->titlecolor         = get_option("showoff-titlecolor", "109,107,95");
        $options->projecttitlecolor  = get_option("showoff-projecttitlecolor", "54,54,54");
        $options->projectinnercolor  = get_option("showoff-projectinnercolor", "101,101,101");
       
        $options->buttonbgcolor        = get_option("showoff-buttonbgcolor", "255,85,86");
        $options->buttoncolor          = get_option("showoff-buttoncolor", "255,255,255");
        $options->buttonbgcolorhover   = get_option("showoff-buttonbgcolorhover", "252,183,85");
        $options->buttoncolorhover     = get_option("showoff-buttoncolorhover", "255,255,255");
        $options->buttonbgcoloractive  = get_option("showoff-buttonbgcoloractive", "188,188,188");
        $options->buttoncoloractive    = get_option("showoff-buttoncoloractive", "255,255,255");
        $options->projectbgcolorhover  = get_option("showoff-projectbgcolorhover", "252,183,85");
        
        
        $options->projecthoverstyle     = get_option("showoff-projecthoverstyle", "title");
        $options->projecthovertype      = get_option("showoff-projecthovertype", "modern");
        $options->projecthoveropacity   = get_option("showoff-projecthoveropacity", "1");
        $options->projectcolorhover     = get_option("showoff-projectcolorhover", "255,255,255");
        $options->projectinnerbgcolor   = get_option("showoff-projectinnerbgcolor", "236,236,236");
        $options->navicolor             = get_option("showoff-navicolor", "205,205,205");
        $options->navicolorhover        = get_option("showoff-navicolorhover", "255,85,86");
        $options->navicoloractive       = get_option("showoff-navicoloractive", "255,85,86");
        
        return $options;
    }
    
    public static function save_options(){
        
        $cols           = (int)    self::REQUEST("cols");
        $perpage        = (int)    self::REQUEST("perpage");
        $spacing        = (int)    self::REQUEST("spacing");
        $aspect         = (float)  self::REQUEST("aspect");
        $focusoffset    = (int)    self::REQUEST("focusoffset");
        $animationtype  = (string) self::REQUEST("animationtype");
        $catfilter      = (string) self::REQUEST("catfilter");
        $cat            = (array)  self::REQUEST("cat");
        $title          = (string) self::REQUEST("title");
        
        $lightbox       = (int)self::REQUEST("lightbox");
        $sharebuttons   = (int)self::REQUEST("sharebuttons");
        
        $buttonsfont      = (string) self::REQUEST("buttonsfont");
        $titlefont        = (string) self::REQUEST("titlefont");
        $projectitlefont  = (string) self::REQUEST("projectitlefont");
        $projecdescfont   = (string) self::REQUEST("projecdescfont");
        $projecthoverfont = (string) self::REQUEST("projecthoverfont");
        
        $titlecolor         = (string) self::REQUEST("titlecolor");
        $projecttitlecolor  = (string) self::REQUEST("projecttitlecolor");
        $projectinnercolor  = (string) self::REQUEST("projectinnercolor");
        
        $buttonbgcolor        = (string) self::REQUEST("buttonbgcolor");
        $buttoncolor          = (string) self::REQUEST("buttoncolor");
        $buttonbgcolorhover   = (string) self::REQUEST("buttonbgcolorhover");
        $buttoncolorhover     = (string) self::REQUEST("buttoncolorhover");
        $buttonbgcoloractive  = (string) self::REQUEST("buttonbgcoloractive");
        $buttoncoloractive    = (string) self::REQUEST("buttoncoloractive");
        $projectbgcolorhover  = (string) self::REQUEST("projectbgcolorhover");
        
        $projecthoverstyle    = (string) self::REQUEST("projecthoverstyle");
        $projecthovertype     = (string) self::REQUEST("projecthovertype");
        $projecthoveropacity  = (string) self::REQUEST("projecthoveropacity");
        $projectcolorhover    = (string) self::REQUEST("projectcolorhover");
        $projectinnerbgcolor  = (string) self::REQUEST("projectinnerbgcolor");
        $navicolor            = (string) self::REQUEST("navicolor");
        $navicolorhover       = (string) self::REQUEST("navicolorhover");
        $navicoloractive      = (string) self::REQUEST("navicoloractive");
        
        
        update_option("showoff-cols", $cols);
        update_option("showoff-perpage", $perpage);
        update_option("showoff-spacing", $spacing);
        update_option("showoff-aspect", $aspect);
        update_option("showoff-focusoffset", $focusoffset);
        
        update_option("showoff-animationtype", $animationtype);
        update_option("showoff-catfilter", $catfilter);
        update_option("showoff-cat", implode(",",$cat));
        update_option("showoff-title", $title);
        
        update_option("showoff-lightbox", $lightbox);
        update_option("showoff-sharebuttons", $sharebuttons);
        
        update_option("showoff-buttonsfont", $buttonsfont);
        update_option("showoff-titlefont", $titlefont);
        update_option("showoff-projectitlefont", $projectitlefont);
        update_option("showoff-projecdescfont", $projecdescfont);
        update_option("showoff-projecthoverfont", $projecthoverfont);
        
        update_option("showoff-titlecolor", $titlecolor);
        update_option("showoff-projecttitlecolor", $projecttitlecolor);
        update_option("showoff-projectinnercolor", $projectinnercolor);
        
        update_option("showoff-buttonbgcolor", $buttonbgcolor);
        update_option("showoff-buttoncolor", $buttoncolor);
        update_option("showoff-buttonbgcolorhover", $buttonbgcolorhover);
        update_option("showoff-buttoncolorhover", $buttoncolorhover);
        update_option("showoff-buttonbgcoloractive", $buttonbgcoloractive);
        update_option("showoff-buttoncoloractive", $buttoncoloractive);
        update_option("showoff-projectbgcolorhover", $projectbgcolorhover);
        
        update_option("showoff-projecthoveropacity", $projecthoveropacity);
        update_option("showoff-projecthoverstyle", $projecthoverstyle);
        update_option("showoff-projecthovertype", $projecthovertype);
        update_option("showoff-projectcolorhover", $projectcolorhover);
        update_option("showoff-projectinnerbgcolor", $projectinnerbgcolor);
        update_option("showoff-navicolor", $navicolor);
        update_option("showoff-navicolorhover", $navicolorhover);
        update_option("showoff-navicoloractive", $navicoloractive);
        
    }
    
    /*
     *  Returns category object array by catid
     *  returns false on empty
     */
    public static function get_category($catid = null) {
        if (!$catid) $catid = (int) self::REQUEST ("catid");
        if ($catid <= 0) return false;
        global $wpdb;
        global $table_prefix;
        $category = $wpdb->get_results("SELECT * FROM {$table_prefix}showoff_categories WHERE id = {$catid}");
        return !empty($category) ? $category[0] : false;
    }
    
    /*
     *  Returns list of categories object array
     */
    public static function get_categories() {
        global $wpdb;
        global $table_prefix;
        
        $categories = $wpdb->get_results("SELECT * FROM {$table_prefix}showoff_categories ORDER BY `ordering`,`id`");
        return !empty($categories) ? $categories : array();
    }
    
    /*
     * Create or Update Category
     */
    public static function create_category() {
        global $wpdb;
        global $table_prefix;
        
        $title     = self::REQUEST("title","post");
        $update    = self::REQUEST("update","post");
        $ordering  = 0;
        
        if (!$title) return new WP_Error("broke", "Category must have title!");
        
        if ($update) :
            $id = (int) $update;
            if ($id <= 0) return false;
            $query = $wpdb->update(
                "{$table_prefix}showoff_categories", array(
                "title" => "{$title}"
                ),
                array('id' => $id),
                array(
                    '%s'
                )
            );
        else :
            $query = $wpdb->insert(
                "{$table_prefix}showoff_categories", array(
                "title"    => "{$title}",
                "ordering" => "{$ordering}"
                ),
                array(
                    '%s',
                    '%d'
                )
            );
        endif;
        
        if ($query === false) :
            $wpdb->show_errors();
            return new WP_Error("broke", "SQL Error: ". $wpdb->last_error);
        endif;
    }
    
    /*
     * Delete Project
     */
    public static function delete_project() {
        global $wpdb;
        global $table_prefix;
        $id = (int) self::REQUEST("id");
        if ($id <= 0) return new WP_Error("broke", "Unable to delete non-existent project!");
        $query = $wpdb->query(
            $wpdb->prepare(
            "
                DELETE FROM {$table_prefix}showoff_projects
                WHERE id = %d
            ", $id
            )
        );
                
        if ($query === false) {
            $wpdb->show_errors();
            return new WP_Error("broke", "SQL Error: " . $wpdb->last_error);
        }
    }
    
    /*
     * Delete Category
     */
    public static function delete_category() {
        global $wpdb;
        global $table_prefix;
        $id = (int) self::REQUEST("catid");
        if ($id <= 0) return new WP_Error("broke", "Unable to delete non-existent category!");
        $query = $wpdb->query(
            $wpdb->prepare(
            "
                DELETE FROM {$table_prefix}showoff_categories
                WHERE id = %d
            ", $id
            )
        );
                
        if ($query === false) {
            $wpdb->show_errors();
            return new WP_Error("broke", "SQL Error: ". $wpdb->last_error);
        }
        
        $query = $wpdb->query(
            $wpdb->prepare(
            "
                DELETE FROM {$table_prefix}showoff_projects
                WHERE catid = %d
            ", $id
            )
        );
                
        if ($query === false) {
            $wpdb->show_errors();
            return new WP_Error("broke", "SQL Error: " . $wpdb->last_error);
        }
        
        $projects = self::get_projects();
        
        foreach ($projects as $project) {
            $cats = explode(",",$project->catid);
            
            if (in_array($id, $cats)) {
                foreach ($cats as $k => $cat) {
                    if ($cat == $id) {
                        unset($cats[$k]);
                    }
                }
                
                $cats = array_values($cats); 
                $catid = self::clean_cat($cats);
                
                $query = $wpdb->update(
                    "{$table_prefix}showoff_projects", 
                    array(
                        "catid"     => "{$catid}"
                    ), 
                    array(
                        'id' => $project->id
                    ), 
                    array(
                        '%s'
                    )
                );
            }
        }
    }

    /*
     * Get list of projects object array
     */
    public static function get_projects() {
        global $wpdb;
        global $table_prefix;
        
        $perpage = 20;
        $page    = max(self::REQUEST("paged") - 1, 0);
        $offset  = $page * $perpage;
        
        $projects = $wpdb->get_results("SELECT * FROM {$table_prefix}showoff_projects ORDER BY `ordering`,`id` LIMIT {$offset}, {$perpage} ");
        return !empty($projects) ? $projects : array();
    }

    /*
     * Get list of projects pages number
     */

    public static function get_projects_pagination() {
        global $wpdb;
        global $table_prefix;
        global $plugin_page;
        $perpage = 20;

        $projects = $wpdb->query("SELECT * FROM {$table_prefix}showoff_projects");

        $pages = max(ceil($projects / $perpage), 0);
        
        $cpage = max(self::REQUEST("paged"),1);
        
        if ($pages <= 1) return;
        
        ob_start();
        for ($page = 1; $page <= $pages; $page++) {
            $k = $cpage == $page ? "active" : "";
            $href = "?page=$plugin_page&paged=$page";
            echo "<li class='$k'><a href='$href'>$page</a></li>";
        }
        return ob_get_clean();
    }
    
    

    /*
     * Get project object array 
     * returns false on empty
     */
    public static function get_project($id = null) {
        $id = (int)self::REQUEST("id");
        if ($id <= 0) return false;
        global $wpdb;
        global $table_prefix;
        $project = $wpdb->get_results("SELECT * FROM {$table_prefix}showoff_projects WHERE id = {$id}");
        return !empty($project) ? $project[0] : false;
    }
    
    /*
     * Create of Update Project
     */

    public static function create_project() {
        global $wpdb;
        global $table_prefix;

        $title     = self::REQUEST("title","post");
        $catid     = self::REQUEST("catid", "post");
        $thumbnail = self::REQUEST("thumbnail", "post");
        $image     = self::REQUEST("image", "post");
        $content   = self::REQUEST("content", "post");
        $readmore  = self::REQUEST("readmore", "post");
        $update    = self::REQUEST("update");
        $ordering  = 0;
        
        if (!$title)     return new WP_Error("broke", "Project must have title!");
        if (!$catid)     return new WP_Error("broke", "Project must have category!");
        if (!$thumbnail) return new WP_Error("broke", "Project must have thumbnail!");
        if ($image) $image = implode("||",$image);
        if (!$content) $content = "";
        if (!$readmore) $readmore = "";
        
        $query = $wpdb->get_var("SELECT MAX(ordering) FROM {$table_prefix}showoff_projects");
        
        if ($query === false) :
            $wpdb->show_errors();
            return new WP_Error("broke", "SQL Error: " . $wpdb->last_error);
        endif;
        
        $ordering = (int) $query + 1;
        
        $catid = self::clean_cat($catid);
        
        if ($update) :
            $id = (int) $update;
            if ($id <= 0) return false;
            $query = $wpdb->update(
                "{$table_prefix}showoff_projects", 
                array(
                    "title"     => "{$title}",
                    "catid"     => "{$catid}",
                    "thumbnail" => "{$thumbnail}",
                    "image"     => "{$image}",
                    "content"   => "{$content}",
                    "readmore"  => "{$readmore}"
                ), 
                array(
                    'id' => $id
                ), 
                array(
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s'
                )
            );
        else :
            $query = $wpdb->insert(
                "{$table_prefix}showoff_projects", 
                 array(
                    "title"     => "{$title}",
                    "catid"     => "{$catid}",
                    "thumbnail" => "{$thumbnail}",
                    "image"     => "{$image}",
                    "content"   => "{$content}",
                    "readmore"  => "{$readmore}",
                    "ordering"  => "{$ordering}"
                ), array(
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%d'
                )
            );
        endif;

        if ($query === false) :
            $wpdb->show_errors();
            return new WP_Error("broke", "SQL Error: " . $wpdb->last_error);
        endif;
    }
    
    /*
     * Project ordering
     */
    public static function order_projects() {
        $order = self::REQUEST("order");
        
        global $wpdb;
        global $table_prefix;
        
        foreach ($order as $k) {
            $k = explode(":",$k);
            $p = (int) $k[0];
            $o = (int) $k[1];
            $query = $wpdb->update(
                "{$table_prefix}showoff_projects", 
                array("ordering" => "{$o}"),
                array("id"    => "{$p}"),
                array('%d'),
                array('%d')
            );
             
            if ($query === false) :
                $wpdb->show_errors();
                return new WP_Error("broke", "SQL Error: " . $wpdb->last_error);
            endif;
        }
    }
    
    
    /*
     * Categories ordering
     */
    public static function order_categories() {
        $order = self::REQUEST("order");
        
        global $wpdb;
        global $table_prefix;
        
        foreach ($order as $k) {
            $k = explode(":",$k);
            $p = (int) $k[0];
            $o = (int) $k[1];
            $query = $wpdb->update(
                "{$table_prefix}showoff_categories", 
                array("ordering" => "{$o}"),
                array("id"    => "{$p}"),
                array('%d'),
                array('%d')
            );
             
            if ($query === false) :
                $wpdb->show_errors();
                return new WP_Error("broke", "SQL Error: " . $wpdb->last_error);
            endif;
        }
    }
    
    
    /*
     * Get list of projects object array FRONT END
     */
    public static function front_get_projects() {
        global $wpdb;
        global $table_prefix;
        
        $options  = self::get_options();
        
        $page     = self::REQUEST("page") ? (int) self::REQUEST("page") : 1;
        $realpage = $page - 1 < 0 ? 0 : $page - 1;
        
        $perpage  = self::REQUEST("perpage") ? (int) self::REQUEST("perpage") : $options->perpage;
        $offset   = $realpage * $perpage;
        
        $cat     = self::REQUEST("cat") ? self::REQUEST("cat") : $options->cat;
        $if_cat  = "";
        
        if ($cat != "0" && !empty($cat)) {
            $catarray = self::clean_cat($cat, 1); // 1 returns array instead of comma separated string
            $if_cat = " WHERE ";
            
            foreach ($catarray as $catid) {
                $if_cat .= " FIND_IN_SET('$catid', catid) ";
                if (end($catarray) !== $catid) {
                    $if_cat .= " OR ";
                }
            }
        }
        
        $projects = $wpdb->get_results("SELECT * FROM {$table_prefix}showoff_projects {$if_cat} ORDER BY `ordering`,`id` LIMIT {$perpage} OFFSET {$offset}");
        return !empty($projects) ? $projects : array();
    }
    
    /*
     *  Returns list of categories object array FRONT END
     */
    public static function front_get_categories() {
        global $wpdb;
        global $table_prefix;
        
        $options = self::get_options();
        $cat     = $options->cat;
        
        $if_cat  = "";
        if ($cat != "0") {
            $cat = self::clean_cat($cat);
            $if_cat = " WHERE `id` IN ({$cat}) ";
        }
        
        $categories = $wpdb->get_results("SELECT * FROM {$table_prefix}showoff_categories {$if_cat} ORDER BY `ordering`,`id` ");
        return !empty($categories) ? $categories : array();
    }
    
    /*
     *  Pagination array FRONT END
     */
    public static function front_get_pagination() {
        global $wpdb;
        global $table_prefix;
        
        $options = self::get_options();
        $cat     = self::REQUEST("cat")     ? self::REQUEST("cat") : $options->cat;
        $perpage = self::REQUEST("perpage") ? (int)self::REQUEST("perpage") : $options->perpage;
        
        if ($cat != "0" && !empty($cat)) {
            $catarray = self::clean_cat($cat, 1); // 1 returns array instead of comma separated string
            $if_cat = " WHERE ";
            
            foreach ($catarray as $catid) {
                $if_cat .= " FIND_IN_SET ('$catid', catid) ";
                if (end($catarray) !== $catid) {
                    $if_cat .= " OR ";
                }
            }
        }
        
        $result  = $wpdb->query("SELECT * FROM {$table_prefix}showoff_projects {$if_cat}");
        $pages   = ceil($result / $perpage);
        return $pages;
    }
}

?>