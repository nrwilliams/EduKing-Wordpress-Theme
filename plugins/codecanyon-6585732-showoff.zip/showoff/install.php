<?php
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
global $wpdb;

$table = $wpdb->prefix . "showoff_categories";

$sql = "CREATE TABLE $table (
       `id`       int(11)      NOT NULL AUTO_INCREMENT,
       `title`    varchar(300) NOT NULL,
       `ordering` int(6)       NOT NULL,
        PRIMARY KEY (`id`)
) CHARSET=utf8;";

dbDelta($sql);

$table = $wpdb->prefix . "showoff_projects";

$sql = "CREATE TABLE $table (
       `id`        int(11)       NOT NULL AUTO_INCREMENT,
       `catid`     varchar(500)  NOT NULL,
       `title`     varchar(300)  NOT NULL,
       `thumbnail` varchar(500)  NOT NULL,
       `image`     text          NOT NULL,
       `content`   text          NOT NULL,
       `readmore`  varchar(500)  NOT NULL,
       `ordering`  int(6)        NOT NULL,
        PRIMARY KEY (`id`)
) CHARSET=utf8;";

dbDelta($sql);

update_option("showoff_db_version","1.06");
?>
