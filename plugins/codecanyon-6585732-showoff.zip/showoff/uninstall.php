<?php
global $wpdb;

$table = $wpdb->prefix . "showoff_categories";
$wpdb->query("DROP TABLE IF EXISTS $table");

$table = $wpdb->prefix . "showoff_projects";
$wpdb->query("DROP TABLE IF EXISTS $table");

$opts = array('showoff-cols', 
              'showoff-perpage',
              'showoff-spacing',
              'showoff-aspect',
              'showoff-focusoffset',
              'showoff-animationtype',
              'showoff-catfilter',
              'showoff-cat',
              'showoff-title',
              'showoff-lightbox',
              'showoff-sharebuttons',
              'showoff-buttonsfont',
              'showoff-titlefont',
              'showoff-projectitlefont',
              'showoff-projecdescfont',
              'showoff-titlecolor',
              'showoff-projecttitlecolor',
              'showoff-projectinnercolor',
              'showoff-buttonbgcolor',
              'showoff-buttoncolor',
              'showoff-buttonbgcolorhover',
              'showoff-buttoncolorhover',
              'showoff-buttonbgcoloractive',
              'showoff-buttoncoloractive',
              'showoff-projecthoveropacity',
              'showoff-projecthoverstyle',
              'showoff-projecthovertype',
              'showoff-projecthoverfont',
              'showoff-projectbgcolorhover',
              'showoff-projectcolorhover',
              'showoff-projectinnerbgcolor',
              'showoff-navicolor',
              'showoff-navicolorhover',
              'showoff-navicoloractive'
        ); 


foreach($opts as $opt) { delete_option($opt);}

delete_option("showoff_db_version");
?>
